<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('background.JPG');
  background-repeat: no-repeat;
  background-size: cover;
}
div.transbox {
  background-color: #ffffff;
  opacity: 0.9;
}
</style>
<title>Login</title>
<?php session_start(); ?>
</head>
<div class = "transbox">
<body>
<form id='login' action='login.php' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Login</legend>
<input type='hidden' name='submitted' id='submitted' value='1'/>
 
<label for='username' >User Name:</label>
<input type='text' name='username' id='username'  maxlength="50" required/>
 
<label for='password' >Password:</label>
<input type='password' name='password' id='password' maxlength="50" required> </input>
 
<input type='submit' name='Submit' value='Submit' />
 
</fieldset>
</form>
</div>

<?php
include 'serverconnect.php';

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
if($post) {
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
    $result = mysqli_query($con, "SELECT * FROM userprofile WHERE username LIKE '%$username%'");
    $row = mysqli_fetch_array($result);
    if($username != $row[0])
    {
        ?>
        <div class = "transbox">
        <?php
        echo "Error logging in. Username does not match";
        ?>
        </div>
        <?php
        return;
    }
    else if($password != $row[1])
    {
         ?>
        <div class = "transbox">
        <?php
        echo "Error logging in. Password does not match.";
        ?>
        </div>
        <?php
        return false;
    }
    else {
    $_SESSION["id"] = $username;
    $_SESSION["password"] = $password;
    header("Location: forecastuserinput.php");
    return true;
    }
}
?>







</body>
</html>

