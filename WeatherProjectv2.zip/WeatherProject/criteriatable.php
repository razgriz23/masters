<?php 
include 'serverconnect.php';
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userparameterselect")
	or die(mysqli_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr> <th>Parameter</th> </tr>";

while($row = mysqli_fetch_array( $result )) {

	echo "<tr>";
		echo '<td>' . $row['parameter'] . '</td>';
		echo '<td>' . '<a href="edit.php">Edit</a>' . '</td>';
		echo '<td>' . '<a href="delete.php?id=' . $row['id'] . '"> Delete</a></td>';
		echo "</tr>"; 
}	

mysqli_close($con);

?>