<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Login</title>
</head>

<body>
<form id='login' action='login.php' method='post' accept-charset='UTF-8'>
<fieldset >
<legend>Login</legend>
<input type='hidden' name='submitted' id='submitted' value='1'/>
 
<label for='username' >UserName:</label>
<input type='text' name='username' id='username'  maxlength="50" required/>
 
<label for='password' >Password:</label>
<input type='password' name='password' id='password' maxlength="50" required/>
 
<input type='submit' name='Submit' value='Submit' />
 
</fieldset>
</form>


<?php
$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';

include 'serverconnect.php';
if($post) {
	$username = trim($_POST['username']);
	$password = trim($_POST['password']);
	echo $username;

	session_start();

	function CheckLoginInDB($username,$password)
	{
    	if(!$this->DBLogin())
    	{
        	$this->HandleError("Database login failed!");
        	return false;
    	}         
    	$username = $this->SanitizeForSQL($username);
    	$pwdmd5 = md5($password);
    	mysqli_query($con, "SELECT * FROM userprofile"); 
    }
}
?>







</body>
</html>

