<?php
include 'style.html';
include 'serverconnect.php';
?>

<!DOCTYPE html>
<html>
<head>
<style>
table {
	border-collapse: collapse;
}
</style>
<?php
$query = "SELECT * FROM userparameterselect";

$result = mysqli_query($con, $query) or die(mysqli_error($con));
                    
$pieData = array();
while ($row = mysqli_fetch_array($result)) {
    $param_type = $row ['parameter'];
    $weight = $row ['weight']; 
    $pieData[] = array($row['parameter'], $row['weight']); 
?>
<tbody>
    <tr>
<?php
}
?> 
                    <!--Load the AJAX API-->
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script type="text/javascript">

          // Load the Visualization API and the piechart package.
          google.load('visualization', '1.0', {'packages':['corechart']});

          // Set a callback to run when the Google Visualization API is loaded.
          google.setOnLoadCallback(drawChart);

          // Callback that creates and populates a data table,
          // instantiates the pie chart, passes in the data and
          // draws it.
          function drawChart() {

            // Create the data table. (and I think this is where I go wrong)
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Parameter');
            data.addColumn('number', 'weight');
            data.addRows(<?php echo json_encode($pieData, JSON_NUMERIC_CHECK); ?>);

            // Set chart options
            var options = {'title':'Closing Criteria',
                           'width':700,
                           'height':400};;

            // Instantiate and draw our chart, passing in some options.
            var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
            chart.draw(data, options);
          }
<?php
mysqli_close($con);
?>
</script>
</head>
<body>

    <!--Div that will hold the pie chart-->
<div id="chart_div"></div>

<div id="chartdescrip">
<?php
include 'serverconnect.php';
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userparameterselect")
	or die(mysqli_error());

$paramTotal = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($paramRow = mysqli_fetch_array( $paramTotal )) {

	$parameterTotal =  $paramRow['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
	$decision = "think about closing down.";
}
else if($parameterTotal >= 100)
{
	$decision = "start taking possible action to close down.";
}
else if($parameterTotal || $parameterTotal == 0)
{
	$decision = "stay open.";
}

echo "<table border='1' cellpadding='1' bordercolor='black' border='solid'>";
echo "<tr>";
echo '<td>' . 'With a total weight of ' . $parameterTotal . ' from the selected parameters above, it has been decided to ' . $decision .'</td>';
echo "</tr>"; 

mysqli_close($con);
?>
</div>
</body>
</html>