<?php
include 'style.html';
include 'serverconnect.php';
?>

<!DOCTYPE html>
<html>
<head>
<style>
table {
	border-collapse: collapse;
}
</style>
<?php
$query = "SELECT * FROM parametercalc";
$querytitle = "SELECT * FROM userinputforecast";

$result= mysqli_query($con, $querytitle) or die(mysqli_error($con));

while($row = mysqli_fetch_array($result)) {
  $title = $row['forecastday'];
}

$result = mysqli_query($con, $query) or die(mysqli_error($con));

$pieData = array();
while ($row = mysqli_fetch_array($result)) {
    $param_type = $row ['parameter'];
    $weight = $row ['weight']; 
    $pieData[] = array($row['parameter'], $row['weight']); 
?>
<tbody>
    <tr>
<?php
}
?> 
                    <!--Load the AJAX API-->
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script type="text/javascript">

          // Load the Visualization API and the piechart package.
          google.load('visualization', '1.0', {'packages':['corechart']});

          // Set a callback to run when the Google Visualization API is loaded.
          google.setOnLoadCallback(drawChart);

          // Callback that creates and populates a data table,
          // instantiates the pie chart, passes in the data and
          // draws it.
          function drawChart() {

            // Create the data table. (and I think this is where I go wrong)
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Parameter');
            data.addColumn('number', 'weight');
            data.addRows(<?php echo json_encode($pieData, JSON_NUMERIC_CHECK); ?>);

            // Set chart options
            var options = {'title':"Recommendation Based on the Following %'s",
                           'width':700,
                           'height':400};;

            // Instantiate and draw our chart, passing in some options.
            var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
            chart.draw(data, options);

            var total = 0;
        for (var i = 0; i < data.getNumberOfRows(); i++) {
            total += data.getValue(i, 1);
        }


        var array = [];
        var percents = [];
          for (var i = 0; i < data.getNumberOfRows(); i++) {
            var label = data.getValue(i, 0);
            var value = data.getValue(i, 1);
            var percent = Number(100 * value / total).toFixed(1); 
            array.push(label);
          }
          document.getElementById("demo").innerHTML = array.join(', ');
          }
</script>
</head>
<body>
    <!--Div that will hold the pie chart-->
<div id="chart_div"></div>

Based on the following forecasted weather conditions:
<p id="demo"></p>
 and the % of their impacts from the Pie Chart, with the higher percentages meaning a more severe impact, the recommendation has been made to

<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
  or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {

  $parameterTotal =  $row['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
  echo "Think about Closing Down";
}
else if($parameterTotal >= 100)
{
  echo "Close";
}
else if($parameterTotal || $parameterTotal == 0)
{
  echo "Stay Open";
} 


mysqli_close($con);
?>
</body>
</html>