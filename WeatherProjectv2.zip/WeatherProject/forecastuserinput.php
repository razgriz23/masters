<!DOCTYPE html>
<? ob_start(); ?>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('background.JPG');
  background-repeat: no-repeat;
  background-size: cover;
}
div.transbox {
  background-color: #ffffff;
  opacity: 0.8;
}
#forecast {
  float: left;
  background: rgba(255,255,255,0.5);
}
.buttonnext {
  padding: 10px;
  float: right;
  color: blue;
}

.back {
  padding: 10px;
  float: left;
  color: red;
}

.forecast {
  background: rgba(255,255,255,0.5);
}

.reset {
  padding: 10px;
  color: green;
}
</style>

<script type="text/javascript">

function stopRKey(evt) {
  var evt = (evt) ? evt : ((event) ? event : null);
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
  if ((evt.keyCode == 13) && (node.type=="text") || (node.type=="radio"))  {return false;}
}

document.onkeypress = stopRKey;
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.3/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script>
$(function() {
$( "#datepicker" ).datepicker();
});




</script>

</head>

<div class = "transbox">
<body bgcolor="#ffffff">
<p1>Enter the forecast for the day of concern below</p1>
<div id="forecast">
<form name="forecast" method = "post">
<hr size=1 noshade>
<h2>User Input Forecast</h2>
<?php
error_reporting(0);
$forecast = $_POST['forecastday']; 
$temp = $_POST['temperature'];
$PrecipType = $_POST['precip'];
$stormType = $_POST['storm'];
$PrecipAmountlow = $_POST['precipa'];
$PrecipAmounthigh = $_POST['precipb'];
$windLow = $_POST['winda'];
$windHigh = $_POST['windb'];
$windGustLow = $_POST['windGa'];
$windGustHigh = $_POST['windGb'];
$cloudCover = $_POST['cloudcover'];

// define the form into a variable
$form = '<table class="forecast" border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right" style="color:red">Day:</div></td>
  <td><input type="text" name="forecastday" size="5" id="datepicker" title="Click this box to pick a date from the calendar" required value="' . $forecast . '"></td>
</tr>
<tr>
  <td><div align="right" style="color:red">Temperature:</div></td>
  <td><input type="number" step="any" name="temperature" size="1" title="Enter a temperature in this box" required value="'. $temp .'">&degF</td>
</tr>
<tr>
  <td>Precip Type</td>
  <td><input type="checkbox" name="precip" value="rain" onClick="">Rain</td>
  <td><input type="checkbox" name="precip" value="snow" onClick="">Snow</td>
  <td><input type="checkbox" name="precip" value="freezing_rain" onClick="">Freezing Rain</td>
</tr>
<tr>
  <td>Storm Type</td>
  <td><input type="checkbox" name="storm" value="blizzard" onClick="">Blizzard (Blizzard Warning Issued)</td>
  <td><input type="checkbox" name="storm" value="ice" onClick="">Ice Storm (Ice Storm Warning Issued)
  <td><input type="checkbox" name="storm" value="severe" onClick="">Severe Storms</td>
  <td><input type="checkbox" name="storm" value="tornado" onClick="">Tornado Outbreak</td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" min="0" step="any" name="precipa" size="1" value="' . $PrecipAmountlow . '"> to <input type="number" min="0" step="any" name="precipb" size="1" value="' . $PrecipAmounthigh . '"> inches</td>
</tr>
<tr>
  <td>Cloud Cover:</td>
  <td><input type="radio" name="cloudcover" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcover" value="partly" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcover" value="mostly" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcover" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td><div style="color:red">Wind Speed:</div></td>
  <td><input type="number" min="0" step="any" name="winda" required value="' . $windLow . '"> to <input type="number" min="0" step="any" name="windb" required value="' . $windHigh . '"> MPH</td>
</tr>
<tr>
  <td><div style="color:red">Wind Gusts:</div></td>
  <td><input type="number" min="0" step="any" name="windGa" required value="' . $windGustLow . '"> to <input type="number" min="0" step="any" name="windGb" required value="' . $windGustHigh . '"> MPH</td>
</tr>
</table>';

echo $form;         // output /display the form
?>


<input type="button" value="Go Back" onclick="window.location.href='index.php'" class="back"> 
<input type="submit" name="submit" value="Next" class="buttonnext">
<button type="reset" value="Reset" class="reset">Reset</button>
<div align="right" style="color:red">Red indicates required</div>
</form>

<?php
error_reporting(E_ALL & ~E_NOTICE);
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

include 'serverconnect.php';
mysqli_query($con, "TRUNCATE TABLE parametercalc");

if($post) {
$forecast = $_POST['forecastday']; 
$temp = $_POST['temperature'];
$PrecipType = $_POST['precip'];
$stormType = $_POST['storm'];
$PrecipAmountlow = $_POST['precipa'];
$PrecipAmounthigh = $_POST['precipb'];
$windLow = $_POST['winda'];
$windHigh = $_POST['windb'];
$windGustLow = $_POST['windGa'];
$windGustHigh = $_POST['windGb'];


if(isset($_POST['cloudcover']))
{
  $cloudcover = $_POST['cloudcover'];
}
if(isset($_POST['storm']))
{
  $stormtype = $_POST['storm'];
}
$totalweight = 0;

if (isset($_POST['precip']) && $PrecipAmountlow == NULL || isset($_POST['precip']) && $PrecipAmounthigh == NULL){
    echo "Please enter an amount for both boxes for Precipitation.";
    return;
}
if($PrecipAmountlow != NULL && $PrecipType == NULL){
    echo "Precipitation Type is required";
    return; 
}
if($temp <= -10 && $temp >= -14)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Temperatures between -10%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($temp <= -15 && $temp >= -19)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Temperatures between -15%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($temp == -20 || $temp == -21)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Temperatures between -20%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($temp <= -22 && $temp > -26)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Temperatures between -22%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($temp <= -26)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Temperature of -26%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}

if($windGustHigh > 0 && $windGustHigh < 15)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 15 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 15 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 15 && $windGustHigh < 20)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 20 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 20 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 20 && $windGustHigh <= 25)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 25 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 25 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 26 && $windGustHigh <= 30)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 30 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 30 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 31 && $windGustHigh <= 40)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 40 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 40 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 41 && $windGustHigh <= 50)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 50 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 50 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 51 && $windGustHigh <= 60)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 60 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 60 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 61 && $windGustHigh <= 70)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 70 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 70 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh >= 71 && $windGustHigh <= 80)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 80 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "Wind gusts up to 80 MPH";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($windGustHigh>= 81)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Winds 81 MPH%'");
  $row = mysqli_fetch_array($result);
  $parameter = "81 MPH or higher in Wind gusts";
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}

if($PrecipType == 'snow' && $PrecipAmounthigh < 5)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 2%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow 2" to 4"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 5)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 5%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 5"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 6)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 6%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 6"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 7)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 7%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 7"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 8)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 8%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 8"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 9)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 9%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 9"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 10)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 10%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 10"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh == 11)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 11%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 11"';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'snow' && $PrecipAmounthigh >= 12)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Snow 12%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Snow up to 12" or more';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}

if($PrecipType == 'freezing_rain' && $PrecipAmounthigh < .10)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to .10 of Freezing Rain%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain up to 0.10 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'freezing_rain' && $PrecipAmounthigh <= .25)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%.10 to%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain up to 0.25 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'freezing_rain' && $PrecipAmounthigh < .75)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Over .25%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain up to 0.75 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'freezing_rain' && $PrecipAmounthigh < 2.00)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 2 inches of Freezing Rain%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain up to 2.00 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'freezing_rain' && $PrecipAmounthigh <= 3.00)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%to 3 inches of Freezing Rain%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain up to 3.00 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($PrecipType == 'freezing_rain' && $PrecipAmounthigh > 3.00)
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Over 3 inches of Freezing Rain%'");
  $row = mysqli_fetch_array($result);
  $parameter = 'Freezing Rain over 3.00 inches';
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}

if($stormtype == 'blizzard')
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Blizzard Warning%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}
else if($stormtype == 'ice')
{
  $result = mysqli_query($con, "SELECT * FROM parametertable WHERE parameter LIKE '%Ice Storm%'");
  $row = mysqli_fetch_array($result);
  $parameter = $row[1];
  $weight = $row[2];
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
  $totalweight += $weight;
}

if($temp <= 40)
{
  $windChillwindlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windLow, 0.16))) + (0.4275*($temp)*(pow($windLow, 0.16)));
  $windChillwindhigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windHigh, 0.16))) + (0.4275*($temp)*(pow($windHigh, 0.16)));
  $windChillwindgustlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustLow, 0.16))) + (0.4275*($temp)*(pow($windGustLow, 0.16)));
  $windChillwindgusthigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustHigh, 0.16))) + (0.4275*($temp)*(pow($windGustHigh, 0.16)));
}
else
{
  $windChillwindlow = 0;
  $windChillwindhigh = 0;
  $windChillwindgustlow = 0;
  $windChillwindgusthigh = 0;
}

echo $stormtype;
mysqli_query($con, "TRUNCATE TABLE userinputforecast");
mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, windlow, windhigh, windgustlow, windgusthigh, stormtype, windchillwindlow, windchillwindhigh, windchillwindgustlow, windchillwindgusthigh) 
    VALUES ('$forecast', '$cloudcover', '$temp', '$PrecipType', '$PrecipAmountlow', '$PrecipAmounthigh', '$windLow', '$windHigh', '$windGustLow', '$windGustHigh', '$stormType', '$windChillwindlow', '$windChillwindhigh', '$windChillwindgustlow', '$windChillwindgusthigh')");
mysqli_query($con, "UPDATE userpreferences SET parameterTotal = '$totalweight'");
exit(header("Location: mainpage.php"));
set_error_handler("var_dump");
}

mysqli_close($con);
?>
<? ob_flush(); ?>
</div>
</div>

</form>
</body>
</html>