<!DOCTYPE html>
<? ob_start(); ?>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;  
}
#forecast {
  float: left;
}

.buttonnext {
  padding: 10px;
  float: right;
  color: blue;
}

.back {
  padding: 10px;
  float: left;
  color: red;
}
</style>

<script type="text/javascript">

function stopRKey(evt) {
  var evt = (evt) ? evt : ((event) ? event : null);
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
  if ((evt.keyCode == 13) && (node.type=="text") || (node.type=="radio"))  {return false;}
}

document.onkeypress = stopRKey;

</script>

</head>

<body bgcolor="#ffffff">
<div id="forecast">
<form name="boxes" method = "post">
<hr size=1 noshade>
<h2>User Input Forecast</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">Day:</div></td>
  <td><input type="date" name="forecastday" size='5' required></td>
</tr>
<tr>
  <td> </td>
  <td>Temperature <input type="number" step="any" name="temperature" size='1' required></td>
</tr>
<tr>
  <td>Precip Type</td>
  <td><input type="radio" name="precip" value="rain" onClick="">Rain</td>
  <td><input type="radio" name="precip" value="snow" onClick="">Snow</td>
  <td><input type="radio" name="precip" value="freezing_rain" onClick="">Freezing Rain</td>
</tr>
<tr>
  <td>Storm Type</td>
  <td><input type="radio" name="storm" value="blizzard" onClick="">Blizzard</td>
  <td><input type="radio" name="storm" value="severe" onClick="">Severe Storms</td>
  <td><input type="radio" name="storm" value="tornado" onClick="">Tornado Outbreak</td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" step="any" name="precipa" size='1'> to <input type="text" step="any" name="precipb" size='1'> inches</td>
</tr>
<tr>
  <td>Cloud Cover:</td>
  <td><input type="radio" name="cloudcoverday" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday" value="partly" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday" value="mostly" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td>Wind Speed:</td>
  <td><input type="number" step="any" name="winda" size='1' required> to <input type="number" step="any" name="windb" size='1' required> MPH</td>
</tr>
<tr>
  <td>Wind Gusts:</td>
  <td><input type="number" step="any" name="windGa" size='1'> to <input type="number" step="any" name="windGb" size='1'> MPH</td>
</tr>
</table>

<?php
  if(isset($_POST['cloudcoverday']))
  {
    $cloudcoverday = $_POST['cloudcoverday'];
  }
?>

<input type="button" value="Go Back" onclick="window.location.href='index.php'" class="back"> 
<input type="submit" name="submit" value="Next" class="buttonnext">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

include 'serverconnect.php';
mysqli_query($con, "TRUNCATE TABLE parametercalc");

if($post) {
$forecast = $_POST['forecastday']; 
$temp = $_POST['temperature'];
$PrecipType = $_POST['precip'];
$stormType = $_POST['storm'];
$PrecipAmountlow = $_POST['precipa'];
$PrecipAmounthigh = $_POST['precipb'];
$windLow = $_POST['winda'];
$windHigh = $_POST['windb'];
$windGustLow = $_POST['windGa'];
$windGustHigh = $_POST['windGb'];

if($temp <= -10 && $temp >= -14)
{
  $parameter = "Temperatures between -10 and -14";
  $weight = 25;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($temp <= -15 && $temp >= -19)
{
  $parameter = "Temperatures between -15 and -19";
  $weight = 50;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($temp <= -20 && $temp >= -21)
{
  $parameter = "Temperatures between -20 to -21";
  $weight = 75;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($temp <= -22 && $temp > -26)
{
  $parameter = "Temperature of -22 to -26";
  $weight = 100;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($temp <= -26)
{
  $parameter = "Temperature of -26 or colder";
  $weight = 150;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}

if($windGustLow >= 10 && $windGustHigh < 15)
{
  $parameter = "10 MPH to 15 MPH in Wind gusts";
  $weight = 15;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 15 && $windGustHigh < 20)
{
  $parameter = "15 MPH to 20 MPH in Wind gusts";
  $weight = 20;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 20 && $windGustHigh <= 25)
{
  $parameter = "20 MPH to 25 MPH in Wind gusts";
  $weight = 25;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 26 && $windGustHigh <= 30)
{
  $parameter = "26 MPH to 30 MPH in Wind gusts";
  $weight = 30;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 31 && $windGustHigh <= 40)
{
  $parameter = "31 MPH to 40 MPH in Wind gusts";
  $weight = 40;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 41 && $windGustHigh <= 50)
{
  $parameter = "41 MPH to 50 MPH in Wind gusts";
  $weight = 60;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 51 && $windGustHigh <= 60)
{
  $parameter = "51 MPH to 60 MPH in Wind gusts";
  $weight = 70;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 61 && $windGustHigh <= 70)
{
  $parameter = "61 MPH to 70 MPH in Wind gusts";
  $weight = 80;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 71 && $windGustHigh <= 80)
{
  $parameter = "71 MPH to 80 MPH in Wind gusts";
  $weight = 100;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}
else if($windGustLow >= 81)
{
  $parameter = "81 MPH or higher in Wind gusts";
  $weight = 200;
  mysqli_query($con, "INSERT INTO parametercalc(parameter, weight) 
    VALUES ('$parameter', '$weight')");
}







if($temp <= 40)
{
  $windChillwindlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windLow, 0.16))) + (0.4275*($temp)*(pow($windLow, 0.16)));
  $windChillwindhigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windHigh, 0.16))) + (0.4275*($temp)*(pow($windHigh, 0.16)));
  $windChillwindgustlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustLow, 0.16))) + (0.4275*($temp)*(pow($windGustLow, 0.16)));
  $windChillwindgusthigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustHigh, 0.16))) + (0.4275*($temp)*(pow($windGustHigh, 0.16)));
}
else
{
  $windChillwindlow = 0;
  $windChillwindhigh = 0;
  $windChillwindgustlow = 0;
  $windChillwindgusthigh = 0;
}


mysqli_query($con, "TRUNCATE TABLE userinputforecast");
mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, windlow, windhigh, windgustlow, windgusthigh, stormtype, windchillwindlow, windchillwindhigh, windchillwindgustlow, windchillwindgusthigh) 
    VALUES ('$forecast', '$cloudcoverday', '$temp', '$PrecipType', '$PrecipAmountlow', '$PrecipAmounthigh', '$windLow', '$windHigh', '$windGustLow', '$windGustHigh', '$stormType', '$windChillwindlow', '$windChillwindhigh', '$windChillwindgustlow', '$windChillwindgusthigh')");
header("Location: mainpage.php");
}

mysqli_close($con);

?>
<? ob_flush(); ?>
</div>

</form>
</body>
</html>