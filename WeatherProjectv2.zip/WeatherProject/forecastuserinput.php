<!DOCTYPE html>
<? ob_start(); ?>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;  
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: #7A991A;
}

#forecast {
  float: left;
}
</style>
<ul>
  <li><a href="index.php">Main Page</a></li>
  <li><a href="adminpanel.php">Admin Panel</a></li>
  <li><a href="edit.php">Add/Edit A Parameter</a></li>
  <li><a href="userparameterselect.php">Select Parameters</a></li>
</ul>
</head>

<body bgcolor="#ffffff">
<div id="forecast">
<form name="boxes" method = "post">
<hr size=1 noshade>
<h2>User Input Forecast</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">Day:</div></td>
  <td><input type="date" name="forecastday" required></td>
</tr>
<tr>
  <td> </td>
  <td>Temperature <input type="number" step="any" name="temperature" required></td>
</tr>
<tr>
  <td>Precip Type</td>
  <td><input type="radio" name="precip" value="rain" onClick="">Rain</td>
  <td><input type="radio" name="precip" value="snow" onClick="">Snow</td>
  <td><input type="radio" name="precip" value="freezing_rain" onClick="">Freezing Rain</td>
</tr>
<tr>
  <td>Storm Type</td>
  <td><input type="radio" name="storm" value="blizzard" onClick="">Blizzard</td>
  <td><input type="radio" name="storm" value="severe" onClick="">Severe Storms</td>
  <td><input type="radio" name="storm" value="tornado" onClick="">Tornado Outbreak</td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" step="any" name="precipa"> to <input type="number" step="any" name="precipb"> inches</td>
</tr>
<tr>
  <td>Cloud Cover:</td>
  <td><input type="radio" name="cloudcoverday" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday" value="partly" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday" value="mostly" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td>Wind Speed:</td>
  <td><input type="number" step="any" name="winda" required> to <input type="number" step="any" name="windb" required> MPH</td>
</tr>
<tr>
  <td>Wind Gusts:</td>
  <td><input type="number" step="any" name="windGa"> to <input type="number" step="any" name="windGb"> MPH</td>
</tr>
</table>

<?php
  if(isset($_POST['cloudcoverday']))
  {
    $cloudcoverday = $_POST['cloudcoverday'];
  }
?>

<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

include 'serverconnect.php';

if($post) {
$forecast = $_POST['forecastday']; 
$temp = $_POST['temperature'];
$PrecipType = $_POST['precip'];
$stormType = $_POST['storm'];
$PrecipAmountlow = $_POST['precipa'];
$PrecipAmounthigh = $_POST['precipb'];
$windLow = $_POST['winda'];
$windHigh = $_POST['windb'];
$windGustLow = $_POST['windGa'];
$windGustHigh = $_POST['windGb'];


if($temp <= 40)
{
  $windChillwindlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windLow, 0.16))) + (0.4275*($temp)*(pow($windLow, 0.16)));
  $windChillwindhigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windHigh, 0.16))) + (0.4275*($temp)*(pow($windHigh, 0.16)));
  $windChillwindgustlow = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustLow, 0.16))) + (0.4275*($temp)*(pow($windGustLow, 0.16)));
  $windChillwindgusthigh = (35.74) + (0.6215*($temp)) - (35.75*(pow($windGustHigh, 0.16))) + (0.4275*($temp)*(pow($windGustHigh, 0.16)));
}
else
{
  $windChillwindlow = 0;
  $windChillwindhigh = 0;
  $windChillwindgustlow = 0;
  $windChillwindgusthigh = 0;
}


mysqli_query($con, "TRUNCATE TABLE userinputforecast");
mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, windlow, windhigh, windgustlow, windgusthigh, stormtype, windchillwindlow, windchillwindhigh, windchillwindgustlow, windchillwindgusthigh) 
    VALUES ('$forecast', '$cloudcoverday', '$temp', '$PrecipType', '$PrecipAmountlow', '$PrecipAmounthigh', '$windLow', '$windHigh', '$windGustLow', '$windGustHigh', '$stormType', '$windChillwindlow', '$windChillwindhigh', '$windChillwindgustlow', '$windChillwindgusthigh')");
header("Location: index.php");
}

mysqli_close($con);
?>
<? ob_flush(); ?>
</div>

</form>
</body>
</html>