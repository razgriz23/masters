<html>
<?php
session_start();
if(sizeof($_SESSION) == 0)
{
  header("Location: login.php");
}
?>
<head>
<title>Admin Panel</title>
<style>
.wrapper {
  width: 95%;
  margin: 0 auto;
}
body {
  font-family: Arial, Helvetica, sans-serif;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}

#form {
  float: left;
}

#masthead {
   position: relative;
    height: 45px; 
}

#change {
   position: absolute;
   left: 10;
   top: 400px;
}


</style>

<div id="masthead" role="banner">
<ul>
  <li><a href="mainpage.php">Main Page</a></li>
  <li><a href="userparameterselect.php">Select Parameters</a></li>
  <li><a href="faq.html">FAQ</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</div>
</head>

<body>

<?php
include 'serverconnect.php';
?>
<div class="wrapper">
<div id='form'>
<form action = "adminpanel.php" method = "post">
<select id="stateName" name="stateName">
<option value = ' '> Please Select A State </option>
<option value = 'Alaska'> Alaska</option>
<option value = 'Alabama'> Alabama</option>
<option value = 'Arkansas'> Arkansas</option>
<option value = 'Arizona'> Arizona</option>
<option value = 'California'> California</option>
<option value = 'Colorado'> Colorado</option>
<option value = 'Illinois'> Illinois</option>
</select>
<input type="submit" name="submit" value="Submit">
</form>
</div>

<?php
$state = isset($_POST["stateName"]) ? $_POST["stateName"] : '';

  if($state == 'Alaska')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AK'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Alaska'");

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
if($post)
{
  header('Location: mainpage.php');
}


   if($state == 'Alabama')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AL'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Alabama'");



if($state == 'Arkansas')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AR'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Arkansas'");


if($state == 'Arizona')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AZ'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Arizona'");

if($state == 'California')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'CA'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'California'");

if($state == 'Colorado')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'CO'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Colorado'");

if($state == 'Illinois')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'IL'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Illinois'");







?>
</div>

<div id="change">
<form name="changeid" method = "post">
<?php
echo "<b>Change username and password for login</b>";
$form = '<table class="user" border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right" style="color:red">UserID(no spaces):</div></td>
  <td><input type="text" name="id" size="10" required ></td>
</tr>
<tr>
  <td><div align="right" style="color:red">Password(no spaces):</div></td>
  <td><input type="password" name="password" size="10" required ></td>
</tr>
<tr>
  <td><div align="right" style="color:red">Re-enter Password:</div></td>
  <td><input type="password" name="password1" size="10" required ></td>
</tr>
</table>';
echo $form;
?>
<div align="center" style="color:red">Red indicates required</div>
<input type="submit" name="submit1" value="Submit" class="buttonnext">
</form>
</div>

<?php
error_reporting(E_ALL & ~E_NOTICE);
$post = isset($_POST["submit1"]) ? $_POST["submit1"] : '';
if($post) {
$username = $_POST['id']; 
$password = $_POST['password'];
$passwordcheck = $_POST['password1'];

if(ctype_space($username))
{
  echo "Please enter in a username and avoid using spaces";
  return;
}
$sessionId = $_SESSION['id'];
if($password != $passwordcheck)
{
  echo "Passwords do not match";
  return;
}
else if(ctype_space($password))
{
  echo "Please enter in a password and avoid using spaces";
  return;
}
else
{
  mysqli_query($con, "UPDATE userprofile
    SET username = '$username', password = '$password'
    WHERE username = '$sessionId'");
  header("location: logout.php");
}

}
?>
</div>
</div>

</body>
</html>
