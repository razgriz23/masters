<html>
<head>
<title>Admin Panel</title>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}

#form {
  float: left;
}

#masthead {
   position: relative;
    height: 45px; 
}
</style>

<div id="masthead" role="banner">
<ul>
  <li><a href="mainpage.php">Main Page</a></li>
  <!---<li><a href="edit.php">Add/Edit A Parameter</a></li>@-->
  <li><a href="userparameterselect.php">Select Parameters</a></li>
  <li><a href="faq.html">FAQ</a></li>
</ul>
</div>
</head>

<body>

<?php
include 'serverconnect.php';
?>

<div id='form'>
<form action = "adminpanel.php" method = "post">
<select id="stateName" name="stateName">
<option value = ' '> Please Select A State </option>
<option value = 'Alaska'> Alaska</option>
<option value = 'Alabama'> Alabama</option>
<option value = 'Arizona'> Arizona</option>
<option value = 'Minneapolis'> Minneapolis</option>
<option value = 'Boston'> Boston</option>
<option value = 'Honolulu,HI'> Honolulu,HI</option>
</select>
<input type="submit" name="submit" value="Submit">
</form>
</div>

<?php
$state = isset($_POST["stateName"]) ? $_POST["stateName"] : '';

  if($state == 'Alaska')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AK'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Alaska'");

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
if($post)
{
  header('Location: mainpage.php');
}


  /*else if($state == 'Alabama')
  {
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AL'");
    $row = mysqli_fetch_array($result);
    echo '<a href="adminpanel.php">' . $row["location"] . '</a>' . '<br>';
    while($row = $result->fetch_assoc())
    {
      echo '<a href="adminpanel.php">' . $row["location"] . '</a>' . '<br>';
    }

    $airportid = $row['airportid'];
    echo $airportid;
    mysqli_query($con, "UPDATE userpreferences SET cityname = '$city' WHERE cityname != '$airportid'");
  

  }*/

  //header('Location: mainpage.php');
  //header('Location: adminpanel.php');

//}
?>
</div>
</body>
</html>
