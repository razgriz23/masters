<html>
<head>
<title>Admin Panel</title>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}

#form {
  float: left;
}

#masthead {
   position: relative;
    height: 45px; 
}
</style>

<div id="masthead" role="banner">
<ul>
  <li><a href="mainpage.php">Main Page</a></li>
  <!---<li><a href="edit.php">Add/Edit A Parameter</a></li>@-->
  <li><a href="userparameterselect.php">Select Parameters</a></li>
  <li><a href="faq.html">FAQ</a></li>
</ul>
</div>
</head>

<body>

<?php
include 'serverconnect.php';
?>

<div id='form'>
<form action = "adminpanel.php" method = "post">
<select id="stateName" name="stateName">
<option value = ' '> Please Select A State </option>
<option value = 'Alaska'> Alaska</option>
<option value = 'Alabama'> Alabama</option>
<option value = 'Arkansas'> Arkansas</option>
<option value = 'Arizona'> Arizona</option>
<option value = 'California'> California</option>
<option value = 'Colorado'> Colorado</option>
<option value = 'Illinois'> Illinois</option>
</select>
<input type="submit" name="submit" value="Submit">
</form>
</div>

<?php
$state = isset($_POST["stateName"]) ? $_POST["stateName"] : '';

  if($state == 'Alaska')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AK'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Alaska'");

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
if($post)
{
  header('Location: mainpage.php');
}


   if($state == 'Alabama')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AL'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Alabama'");



if($state == 'Arkansas')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AR'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Arkansas'");


if($state == 'Arizona')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'AZ'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Arizona'");

if($state == 'California')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'CA'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'California'");

if($state == 'Colorado')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'CO'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Colorado'");

if($state == 'Illinois')
  {
  ?>
    <form action = "adminpanel.php" method = "post">
    <select id="cityName" name="cityName">
    <option value = ' '> Please Select A City/Airport </option>
  <?php 
    $result = mysqli_query($con, "SELECT * FROM cities WHERE state = 'IL'");
    $row = mysqli_fetch_array($result);
  ?>
    <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
  <?php
    while($row = $result->fetch_assoc())
    {
      ?>
      <option value = <?php echo $row["airportid"] ?> > <?php echo $row["location"] ?> </option>
      <?php 
    }
  ?>
    </select>
    <input type="submit" name="Submit" value="Submit">
    </form>
  <?php 
  }

$post = isset($_POST["Submit"]) ? $_POST["Submit"] : '';
$city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
mysqli_query($con, "UPDATE userpreferences SET cityname = '$city'");
mysqli_query($con, "UPDATE userpreferences SET state = 'Illinois'");







?>
</div>
</body>
</html>
