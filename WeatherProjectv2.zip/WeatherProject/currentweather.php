<?php
include 'amit1.php';

$city = $cityName;
echo $city;

?>