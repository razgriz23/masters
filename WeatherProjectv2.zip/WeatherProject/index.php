<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Welcome!</title>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('background.JPG');
  background-repeat: no-repeat;
  background-size: cover;
}
.button {
  padding: 10px;
  color: black;
  float: center;
}
div.transbox {
	background-color: #ffffff;
	opacity: 0.6;
}
</style>
</head>

<body>
<div class = "transbox">
<h1>Welcome to the Closing Decision Maker Page!</h1>
<p1>Weather isn't a simple problem in our world. It's always changing and forecasting the changes are a big part of our lives. From blizzards to tornado outbreaks, the ability to get to school or work from our homes is all dependent on the days weather. The purpose of this website is to aid those who decide if a business or school should close the following day or remain open.</p1>

<h2>So what can I do with this site?</h2>
<p2>This site allows you to enter a forecast for the day of concern and will output a closing recommendation based on the forecast.</p2>
</div>
<button onclick="window.location.href='forecastuserinput.php'" class="button" >Click Here To Get Started</button>
</body>
</html>