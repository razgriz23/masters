<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>Welcome!</title>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}
.button {
  padding: 10px;
  float: center;
}
</style>

<h1>Welcome to the Closing Decision Maker Page!</h1>
</head>

<body>

<p1>Weather isn't a simple problem in our world. It's always changing and forecasting the changes are a big part of our lives. From blizzards to tornado outbreaks, the ability to get to school or work from our homes is all dependent on the days weather. The purpose of this website is to aid those who decide if a business or school should close the following day or remain open.</p1>

<h2>So what can I do with this site?</h2>

<button onclick="window.location.href='forecastuserinput.php'" class="button" >Click Here To Get Started</button>
</body>
</html>