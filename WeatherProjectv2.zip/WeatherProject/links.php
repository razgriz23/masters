<?php

//Illinois Cities
$OHare = 'http://w1.weather.gov/data/METAR/KORD.1.txt';
$Midway = 'http://w1.weather.gov/data/METAR/KMDW.1.txt';
$DeKalb = 'http://w1.weather.gov/data/METAR/KDKB.1.txt';
$Minneapolis = 'http://w1.weather.gov/data/METAR/KMSP.1.txt';
$Boston = 'http://w1.weather.gov/data/METAR/KBOS.1.txt';
$Honolulu = 'http://w1.weather.gov/data/METAR/PHNL.1.txt';
?>