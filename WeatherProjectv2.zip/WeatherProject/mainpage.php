<!DOCTYPE html>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
include 'serverconnect.php';
/*Note: to find any pieces of code to change, such as forecast, do a search for div i="*/
?>
<head>
<style type="text/css">
table{
  margin: 50px 0;
}
.centerText{
   text-align: center;
}
</style>
<style>
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	font-family: Arial, Helvetica, sans-serif;
}

li {
	float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}
</style>

<style>
body {
	font-family: Arial, Helvetica, sans-serif;
}
#criteria {
	position: absolute;
	top: 200px;
	left: 0;
	right: 0;
	
	margin: auto;
}
#currentwx {
	position: absolute;
	left: 800px;
}
#decision {
	position: absolute;
	left: 100px;
	top: 85px;
	border: 2px solid red;
	font-family: Arial, Helvetica, sans-serif;
}
.buttonback {
  position: relative;
  padding: 10px;
  top: 500px;
  left: 500px;
  color: red;
}
</style>
</head>
<body>
<ul>
	<li><a href="adminpanel.php">Admin Panel</a></li>
	<li><a href="faq.html">Help</a></li>
</ul>


<div id="decision">

Recommendation:
<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {

	$parameterTotal =  $row['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
	echo "Think about Closing Down";
}
else if($parameterTotal >= 100)
{
	echo "Close";
}
else if($parameterTotal || $parameterTotal == 0)
{
	echo "Stay Open";
}
?>
</div>

<div id="criteria">
<?php
	 include('SevereWeatherModel.php');
?>
</div>

<div id="currentwx">
<?php
	include('currentwx.php');
?>
</div>

<button onclick="window.location.href='forecastuserinput.php'" class="buttonback" >Go Back</button>


</body>
</html>