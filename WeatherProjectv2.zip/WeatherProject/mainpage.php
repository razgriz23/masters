<!DOCTYPE html>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
include 'serverconnect.php';
/*Note: to find any pieces of code to change, such as forecast, do a search for div i="*/
?>
<head>
<style type="text/css">
table{
  margin: 50px 0;
}
.centerText{
   text-align: center;
}
</style>
<style>
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	font-family: Arial, Helvetica, sans-serif;
}

li {
	float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}
</style>

<style>
body {
	font-family: Arial, Helvetica, sans-serif;
}
#criteria {
	position: absolute;
	top: 200px;
	left: 0;
	right: 0;
	
	margin: auto;
}
#currentwx {
	position: absolute;
	left: 800px;
}
#decision {
	position: absolute;
	left: 100px;
	top: 85px;
	border: 2px solid red;
	font-family: Arial, Helvetica, sans-serif;
}
#chartdescrip {
  position: absolute;
  top: 450px;
}
.buttonback {
  position: relative;
  padding: 10px;
  left: 900px;
  color: red;
}
</style>
</head>
<body>
<ul>
	<li><a href="adminpanel.php">Admin Panel</a></li>
	<li><a href="faq.html">Help</a></li>
</ul>


<div id="decision">

Decision:
<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {

	$parameterTotal =  $row['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
	echo "It would be best to think about closing down.";
}
else if($parameterTotal >= 100)
{
	echo "Highly suggest to close down.";
}
else if($parameterTotal || $parameterTotal == 0)
{
	echo "No need to close down.";
}
?>
</div>

<div id="criteria">
<?php
	 include('SevereWeatherModel.php');
?>
</div>

<div id="currentwx">
<?php
	include('currentwx.php');
?>
</div>

<div id="chartdescrip">
<?php
include 'serverconnect.php';
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userparameterselect")
	or die(mysqli_error());

$paramTotal = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($paramRow = mysqli_fetch_array( $paramTotal )) {

	$parameterTotal =  $paramRow['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
	$decision = "think about closing down.";
}
else if($parameterTotal >= 100)
{
	$decision = "start taking possible action to close down.";
}
else if($parameterTotal || $parameterTotal == 0)
{
	$decision = "stay open.";
}

echo "<table border='1' cellpadding='1' bordercolor='black' border='solid'>";
echo "<tr>";
echo '<td>' . 'With a total weight of ' . $parameterTotal . ' from the selected parameters above, it has been decided to ' . $decision .'</td>';
echo "</tr>"; 

mysqli_close($con);
?>
</div>

<div id="forecast">
<?php
/*include('serverconnect.php');
$result = mysqli_query($con, "SELECT * FROM userinputforecast")
	or die(mysqli_error($con));

$rowcnt = $result->num_rows;

$forecastInput = array();
while($row = mysqli_fetch_array( $result )) {

	array_push($forecastInput, $row);

}

echo '<br>';
mysqli_close($con);


if($forecastInput[0][0] == 'today')
{
	$currentDay = 'Today';
}
else if($forecastInput[0][0] == 'this_afternoon')
{
	$currentDay = 'This Afternoon';
}
else if($forecastInput[0][0] == 'tonight')
{
	$currentDay = 'Tonight';
}

if($forecastInput[1][0] == 'tonight')
{
	$forecastPeriod1 = 'Tonight';
}
else if($forecastInput[1][0] == 'tomorrow')
{
	$forecastPeriod1 = 'Tomorrow';
}
else if($forecastInput[1][0] == 'tomorrow_night')
{
	$forecastPeriod1 = 'Tomorrow Night';
}

if($forecastInput[2][0] == 'tomorrow_night')
{
	$forecastPeriod2 = 'Tomorrow Night';
}
else if($forecastInput[2][0] == 'Sunday')
{
	$forecastPeriod2 = 'Sunday';
}
else if($forecastInput[2][0] == 'Monday')
{
	$forecastPeriod2 = 'Monday';
}
else if($forecastInput[2][0] == 'Tuesday')
{
	$forecastPeriod2 = 'Tuesday';
}
else if($forecastInput[2][0] == 'Wednesday')
{
	$forecastPeriod2 = 'Wednesday';
}
else if($forecastInput[2][0] == 'Thursday')
{
	$forecastPeriod2 = 'Thursday';
}
else if($forecastInput[2][0] == 'Friday')
{
	$forecastPeriod2 = 'Friday';
}
else if($forecastInput[2][0] == 'Saturday')
{
	$forecastPeriod2 = 'Saturday';
}


#precip
if($forecastInput[0][3] == 'clear')
{
	$currentDayPrecip = '';
}
else if($forecastInput[0][3] == 'rain')
{
	$currentDayPrecip = 'Rain';
}
else if($forecastInput[0][3] == 'snow')
{
	$currentDayPrecip = 'Snow';
}
else if($forecastInput[0][3] == 'storms')
{
	$currentDayPrecip = 'Storms';
}









if($forecastInput[0][1] == 'clear_skies')
{
	$currentDayCloud = 'Clear Skies';
	if($currentDay == 'Today' || $currentDay == 'This Afternoon')
	{
		$currentDaySymbol = '<img src="Sunny.png" alt="Sunny" style="width:100px; height:100px">';
	}
	if($currentDay == 'Tonight')
	{
		$currentDaySymbol = '<img src="clear-night.png" alt="MostlyCloudy" style="width:100px; height:100px">';
	}
}
else if($forecastInput[0][1] == 'partly')
{
	$currentDayCloud = 'Partly Cloudy';
	if($currentDay == 'Today' || $currentDay == 'This Afternoon')
	{
		$currentDaySymbol = '<img src="partly-cloudy-day.png" alt="ParltyCloudy" style="width:100px; height:100px">';
	}
	if($currentDay == 'Tonight')
	{
		$currentDaySymbol = '<img src="partlycloudynight.png" alt="ParltyCloudyNight" style="width:100px; height:100px">';
	}
}
else if($forecastInput[0][1] == 'mostly')
{
	$currentDayCloud = 'Mostly Cloudy';
	if($currentDay == 'Today' || $currentDay == 'This Afternoon')
	{ 
		$currentDaySymbol = '<img src="mostlycloudyday.png" alt="MostlyCloudy" style="width:100px; height:100px">';
	}
	if($currentDay == 'Tonight')
	{	 
		$currentDaySymbol = '<img src="mostly-cloudy-night.png" alt="MostlyCloudyNight" style="width:100px; height:100px">';
	}
}
else if($forecastInput[0][1] == 'cloudy')
{
	$currentDayCloud = 'Cloudy';
	$currentDaySymbol = '<img src="cloudy.png" alt="Cloudy" style="width:100px; height:100px">';

	if($currentDayPrecip == 'Rain')
	{
		$currentDaySymbol = '<img src="rain.png" alt="Rain" style="width:100px; height:100px">';
	}

	if($currentDayPrecip == 'Snow')
	{
		$currentDaySymbol = '<img src="snow.jpg" alt="Snow" style="width:100px; height:100px">';
	}

	if($currentDayPrecip == 'Storms')
	{
		$currentDaySymbol = '<img src="storms.png" alt="Storms" style="width:100px; height:100px">';
	}
}



$currentDayTemps = $forecastInput[0][2];




echo "<table border='1' cellpadding='1'>";
echo "<tr> <th>Forecast</th></tr>";
echo "<tr> <th> </th> <th>Forecast Day</th> <th>Cloud Cover</th> <th>Temperatures</th> <th>Precipitation</th></tr>";
echo "<tr>";
	echo '<td>' . $currentDaySymbol . '</td>';
	echo '<td>' . $currentDay . '</td>';
	echo '<td>' . $currentDayCloud . '</td>';
	echo '<td class="centerText">' . $currentDayTemps . '</td>';
	echo '<td class="centerText">' . $currentDayPrecip . '</td>';
echo "</tr>"; 
class="centerText">' . $forecastPeriod2Precip . '</td>';
echo "</tr>";
*/

?>

</div>


<button onclick="window.location.href='forecastuserinput.php'" class="buttonback" >Go Back</button>


</body>
</html>