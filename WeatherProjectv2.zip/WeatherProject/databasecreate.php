<?php
include "serverconnect.php";

$conn = new mysqli($servername, $username, $password);
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

// Create database
try {
	$con = new PDO("mysql:host=$servername", $username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "CREATE DATABASE weatherproject";
	$con->exec($sql);
}

catch(PDOException $e)
{
	$e->getMessage();
}

$conn->select_db("weatherproject");
$dbname = "weatherproject";

try {
	$con = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$sql = "CREATE TABLE parametertable (
	id int(255) PRIMARY KEY AUTOINCREMENT,
	parameter TEXT NOT NULL,
	weight FLOAT NOT NULL
	)";

	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try 
{
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO parametertable (parameter, weight)
	VALUES ('Temperatures between -10 and -14', 25),
	('Temperatures between -15 and -19', 50),
	('Temperatures between -20 t0 -21', 75),
	('Temperatures between -22 to -26', 100),
	('Temperature of -26 or colder', 150),
	('Winds 15 to 20 MPH in Gusts', 20),
	('Winds 20 to 25 MPH in Gusts', 25),
	('Winds 26 to 30 MPH in Gusts', 30),
	('Winds 31 to 40 MPH in Gusts', 40),
	('Winds 41 to 50 MPH in Gusts', 60),
	('Winds 51 to 60 MPH in Gusts', 70),
	('Winds 61 to 70 MPH in Gusts', 80),
	('Winds 71 to 80 MPH in Gusts', 100),
	('Winds 81 MPH or higher in Gusts', 200),
	('Snow 2-4 inches', 25),
	('Snow 5 inches', 30),
	('Snow 6 inches', 40),
	('Snow 7 inches', 50),
	('Snow 8 inches', 60),
	('Snow 9 inches', 75),
	('Snow 10 inches', 80),
	('Snow 11 inches', 85),
	('Snow 12 inches or More', 100),
	('Busses are inoperable due to being unable to start, stop properly, or are stuck', 100),
	('NIU Grounds department is overwhelmed and cannot get a sufficient number of parking lots or spaces open for staff and students', 100),
	('A state of emergency declared by the Governor of Illinois, or other local, state, or federal governmental officials', 100),
	('An ice storm warning issued by the National Weather Service', 100),
	('A blizzard warning issued by the National Weather Service', 100),
	('A Trace to .10 of Freezing Rain', 50),
	('.10 to .25 inches of Freezing Rain', 70),
	('Over .25 inches of Freezing Rain', 100),
	('Over .75 to 2 inches of Freezing Rain', 200),
	('Over 2 to 3 inches of Freezing Rain', 300),
	('Over 3 inches of Freezing Rain', 500),
	('Snow, or snow mixed with sleet ended as of 8 AM on a business day between 2 to 4 inches', 25),
	('Tornado Watch issued', 25),
	('Particularly Dangerous Situation(PDS) Tornado Watch issued', 75),
	('Rainfall over 1 inch', 10)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	$e->getMessage();
}

try {
	$sql = "CREATE TABLE userprofile (
	username VARCHAR(30) NOT NULL,
	password VARCHAR(30) NOT NULL
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try 
{
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO userprofile (username, password)
	VALUE ('root', 'admin')";
	$con->exec($sql);
}
catch(PDOException $e)
{
	$e->getMessage();
}

try {
	$sql = "CREATE TABLE parametercalc (
	id int(255) PRIMARY KEY AUTOINCREMENT,
	parameter TEXT NOT NULL,
	weight FLOAT NOT NULL
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try {
	$sql = "CREATE TABLE userinputforecast (
	forecastday TEXT,
	cloudcover TEXT,
	temperature varchar(5),
	preciptype TEXT,
	precipamountlow varchar(5),
	precipamounthigh varchar(5),
	windlow float,
	windhigh float,
	windgustlow float,
	windgusthigh float,
	stormtype varchar(20),
	windchillwindlow float,
	windchillwindhigh float,
	windchillwindgustlow float,
	windchillwindgusthigh float
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try {
	$sql = "CREATE TABLE userpreferences (
	state TEXT,
	cityname TEXT,
	parameterTotal int(255)
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try 
{
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO userpreferences (state, cityname, parameterTotal)
	VALUE ('Illinois', 'KORD', 0)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	$e->getMessage();
}

try {
	$sql = "CREATE TABLE cities (
	state TEXT,
	location TEXT,
	airportid TEXT
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

$fileTemp = "cities.csv";
$fp = fopen($fileTemp,'r');
$datas = array()
while (($data = fgetcsv($fp)) !== FALSE)
{
     $data['state'] = trim($data[0]);
     $data['location'] = trim($data[1]);
     $data['airportid'] = trim($data[2]);
     $datas[] = $data;
}


try 
{
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO cities (state, location, airportid)
	VALUES" while (($data = fgetcsv($fp)) !== FALSE)
	{
     $data['state'] = trim($data[0]);
     $data['location'] = trim($data[1]);
     $data['airportid'] = trim($data[2]);
     $datas[] = $data;
	};
	$con->exec($sql);
}
catch(PDOException $e)
{
	$e->getMessage();
}


$con = null;
$conn->close();
?>