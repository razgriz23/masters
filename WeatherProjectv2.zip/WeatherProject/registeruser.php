<?php 
$servername = "localhost";
$serverusername = "root";
$serverpassword = "Weather8";


$conn = new mysqli($servername, $serverusername, $serverpassword);
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

$dbname = "weatherproject";

$username = $_POST["username"];
$password = $_POST["password"];

	try
	{
		$con = new PDO("mysql:host=$servername;dbname=$dbname", $serverusername, $serverpassword);
		$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	

		$sql = "INSERT INTO userprofile (username, password)
	        VALUES (?, ?)";

		$statement = $con->prepare($sql);
		$statement->bindValue(1, $_POST["username"]);
		$statement->bindValue(2, $_POST["password"]);
		$statement->execute();	
	}

	catch (PDOException $e)
	{
		echo 'Connection failed ' . $e->getMessage();
	}

	session_start();
	$_SESSION['loggedIn'] = true;
	$_SESSION['userName'] = $_POST["username"];
	$con = null;
	header('Location: http://localhost/amit/SevereWeatherModel.php');
?>