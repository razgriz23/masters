<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<body>

Logging Out...
<?php
session_unset();

session_destroy();

header("Location: index.php");
exit;
?>

</body>
</html>