<!doctype html>
<html lang="en">

<head>
<meta charset="utf-8">
<title>FAQ</title>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('background.JPG');
  background-repeat: no-repeat;
  background-size: cover;
}

div.transbox {
  background-color: #ffffff;
  opacity: 0.7;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}

#accordion {
    float: left;
}
#masthead {
   position: relative;
    height: 45px; 
}
</style>
<div id="masthead" role="banner">
<ul>
    <li><a href="guestpage.php">Main Page</a></li>
    <!---<li><a href="edit.php">Add/Edit A Parameter</a></li>---->
</ul>
</div>


<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>

<div class = "transbox">
<h1>Welcome!</h1>
</head>

<body>

<div id="accordion">
<h3>What does the pie chart represent?</h3>
<div>
<p>The pie chart on the main page represents the closing parameters that you selected. Higher the weight on the closing parameter, the bigger the slice will be on the pie chart.</p>
</div>
<h3>What do the weights represent?</h3>
<div>
<p>The weights represent the severity of a parameter. For example, 1-2 inches of snow will not have as much of an impact as say 9-10 inches would. *NOTE* This is all depending on where you are located. The severity of 1-2 inches of snow may be crippling for areas that lack the ability to keep roadways clear. This will also apply to all the other criteria. Each weight will be entered from a user's perspective.</p>
</div>
<h3>How is the closing weight total determined?</h3>
<div>
<p>The weight total that determines if a business/school should stay open or close is determined by adding up all the weights together. Being an open-sourced project with the code readily available to the general public, further sophisticated calculations can be added to this project and even Machine Learning algorithms.</p>
</div>
<h3>What are the cutoff points in determing if a business/school should close?</h3>
<div>
<p>The cutoff points are as follows: Anything under 50 and including 50 remains open, anything over 50 and under 100 is where the staff should think about closing, and anything over 100 means you should shut down.</p>
</div>
</div>

<script>
$( "#accordion" ).accordion();
</script>


</body>
</html>