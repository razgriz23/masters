<?php

//Illinois Cities
$OHare = 'http://w1.weather.gov/data/METAR/KORD.1.txt';
$Midway = 'http://w1.weather.gov/data/METAR/KMDW.1.txt';
$Minneapolis = 'http://w1.weather.gov/data/METAR/KMSP.1.txt';
?>