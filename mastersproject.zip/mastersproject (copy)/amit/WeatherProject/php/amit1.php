<?php
include 'dataLinks.php';
include 'mainpage.html';
echo "<br>";
echo "<br>";

/*substr(1, 2, 3): 
1: input string to change up
2: start position in the string
3: length. If positive, string will be returned and will contain charachters from the 
start(2 argument in substr). If negative, those characters will be omitted from the end
of the string*/
/*substr_replace(1, 2, 3, 4)
1: input string to change up
2: replacement string
3: start position
4: length
*/

date_default_timezone_set('Etc/UTC'); //ensure the time zone is set to UTC as weather stations use this notation
if($cityName == ' ')
{
	echo 'test';
	exit();
}
else if($cityName == 'Chicago(OHare)')
{
	$url = $OHare;
	$cityName = 'KORD';
}
else if($cityName == 'Chicago(Midway)')
{
	$url = $Midway;
	$cityName = 'KMDW';
}
else if($cityName == 'Minneapolis')
{
	$url = $Minneapolis;
	$cityName = 'KMSP';
}

$output = file_get_contents($url);

//Section to get rid of the junk before Airport ID
$cityLoc = strpos($output, $cityName); //search output for the Airport(cityName) id
$remove = substr($output, 0, $cityLoc); 
$len = strlen($remove);
$pos = strpos($remove, $output);
$newOutput = substr_replace($output, '', $pos, $len);

//echo $newOutput;
//Airport ID is the first item in the field of text
$cityLoc = strpos($newOutput, $cityName);
$len = strlen($cityName); //determine length of the Airport ID to remove to get our date

//remove the Airport ID from the line of text. First item will be the date of observation
$remove = substr($newOutput, 0, $cityLoc); 
$newOutput = substr_replace($newOutput, '', 0, $len);
echo "<br>";
//get date of observation. First, check the time to determine the date.
//Anything before 00Z(UTC), will be day -1. Date will be in UTC on observation.
$timeLocZ = strpos($newOutput, 'Z');
$timeLoc = $timeLocZ - 4;
$time = substr($newOutput, $timeLoc, 4);

$day = date("d");
/*if($time >= 00 && $time < 06)
{
	$day = $day - 1;
}
else 
{
	$day = date("d");
}
echo $day;*/

//remove the time and date and get rest of the info
$newOutput = explode(' ', $newOutput);
unset($newOutput[0]);
unset($newOutput[1]);
$Output = array_values($newOutput);
print_r($Output);
//first index in array will contain the wind data
//check the length of this index. Normal is 7. 8 means the wind is 100 knots or greater
$len = strlen($Output[0]);
$windLocKT = strpos($Output[0], 'KT');
$Output1 = $Output;
$value = array_shift($Output1); //take the first value of the array

$removeWindSpeed = substr($value, 0, $windLocKT - 2);
$windDirection = $removeWindSpeed;

$newOutput = $Output1;

$output = implode(' ', $newOutput);

echo $output;

$smLoc = strpos($output, 'SM');
$visibility = substr($output, 0, $smLoc); 

//$pos = strpos($remove, $output);
//$newOutput = substr_replace($output, '', $pos, $len);

echo "<br>";

echo "Wind Direction: " . $windDirection . "<br>";
echo "Visibility: " . $visibility . "<br>"; 
//Get the wind direction. == is used in PHP for equals.
if($windDirection == 0)
{
	echo "North";
}
else if($windDirection > 0 && $windDirection < 45)
{
	echo "North North East";
}
else if($windDirection == 45)
{
	echo "North East";
}
else if($windDirection > 45 && $windDirection < 90)
{
	echo "East North East";
}
else if($windDirection == 90)
{
	echo "East";
}
else if($windDirection > 90 && $windDirection < 135)
{
	echo "East South East";
}
else if($windDirection == 135)
{
	echo "South East";
}
else if($windDirection > 135 && $windDirection < 180)
{
	echo "South South East";
}
else if($windDirection == 180)
{
	echo "South";
}
else if($windDirection > 180 && $windDirection < 225)
{
	echo "South South West";
}
else if($windDirection == 225)
{
	echo "South West";
}
else if($windDirection > 225 && $windDirection < 270)
{
	echo "West South West";
}
else if($windDirection == 270)
{
	echo "West";
}
else if($windDirection > 270 && $windDirection < 315)
{
	echo "West North West";
}
else if($windDirection == 315)
{
	echo "North West";
}
else if($windDirection > 315 && $windDirection <= 359)
{
	echo "North North West";
}
/*$day = strpos($newOutput, $day); //location of date
$remove = substr($newOutput, $day, strlen($day)+1); //they use 05 for single digit days
$len = $day + 2; 
$pos = strpos($remove, $newOutput);
$newOutput = substr_replace($newOutput, '', $pos, $len); //remove everything up to time of update

echo "<br>";
date_default_timezone_set("America/Chicago");
echo date("m-d-y");*/



/*$con=mysqli_connect('localhost', 'root', 'Weather8', 'test');
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

mysqli_query($con, "INSERT INTO currentweather (Location)
	VALUES ('$setCity')");

mysqli_close($con);*/

?>

<html>
<body>
Last Update: 
<?php
	//echo $lastUpdate;	
?>
</body>
</html>
