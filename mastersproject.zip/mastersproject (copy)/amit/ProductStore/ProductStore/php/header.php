<?php if (session_id() == '') session_start(); ?>
<header class="siteHeader">
	<a href="index.php"><h1>Site Logo</h1></a>
	<form action="categories.php" method="post"> 
		Categories:  
		<select name="categories">
			  <option value="computers">Computers</option>			  
			  <option value="books">Books</option>
			  <option value="education">Education</option>
			  <option value="clothing">Clothing</option>
		</select> 
		<input class="submit-button" type="submit" value="Search">
	</form>

	<?php 
		if (session_id() != '' && isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true)
		{
			echo "<form action=\"logout.php\" method=\"post\">";
			echo "<div class=\"greeting\">";
			echo "<span>Signed in as: " . $_SESSION['userName'] . "</span> ";
			echo "<input class=\"submit-button\" type=\"submit\" value=\"Logout\">";			
			echo "</div>";
			echo "</form>";
			echo "<span class=\"itemAdded\">Item successfully added!</span>";
			echo "<figure class=\"cart\">";

			//check for the number of items in cart
			if (isset($_SESSION['itemsInCart'])) 
			{
				echo "<a href=\"myCart.php\">";
				echo "<span>" . $_SESSION['itemsInCart'] . "</span>";
				echo "</a>";
				/*echo "<script>";
				echo "$(function(){
					$('.itemAdded').fadeTo(1000, 1).delay(2000).fadeTo(1000, 0);
				})";
				echo "</script>";*/
			}

			echo "</figure>";
		}

		else
		{
			echo "<form action=\"userLogin.php\" method=\"post\">";
			echo "<div class=\"login\">";
			echo "Email: <input type=\"text\" name=\"userEmail\"> ";
			echo "Password: <input type=\"password\" name=\"userPassword\"> ";
			echo "<input class=\"submit-button\" type=\"submit\" value=\"Login\"><br />";

			if (!stristr($_SERVER['PHP_SELF'], "register.php"))
			{
				echo "<a href=\"register.php\">New User?</a>";
			}

			echo "</div>";
			echo "</form>";
		}

		/* Login Error Messages */
		if (isset($_SESSION['loginIncorrect']) && $_SESSION['loginIncorrect'] == true)
		{
			echo "<p class=\"loginError\">Incorrect credentials</p>";
		}

		else if (isset($_SESSION['loginEmpty']) && $_SESSION['loginEmpty'] == true)
		{
			echo "<p class=\"loginError\">No value was entered</p>";
		}

		else if (isset($_SESSION['loginToViewCart']) && $_SESSION['loginToViewCart'] == true)
		{
			echo "<p class=\"loginError\">Please log in to view your cart</p>";
		}
	?>
</header>