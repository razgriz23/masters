<?php

include 'serverconnect.php';

if(isset($_GET['id']))
{
	$id = $_GET['id'];

	$record = mysqli_query($con, "DELETE FROM parametertable WHERE id = $id")
	or die(mysqli_error());

	header("Location: SevereWeatherModel.php");
}



?>