<?php
include 'dataLinks.php';
include 'mainpage.html';
echo "<br>";
echo "<br>";

date_default_timezone_set('Etc/UTC'); //ensure the time zone is set to UTC as weather stations use this notation
if($cityName == ' ')
{
	echo 'test';
	exit();
}
else if($cityName == 'Chicago(OHare)')
{
	$url = $OHare;
	$cityName = 'KORD';
}
else if($cityName == 'Chicago(Midway)')
{
	$url = $Midway;
	$cityName = 'KMDW';
}

$output = file_get_contents($url);

#Search and get the City that the data is being used
echo $cityName;
echo "<br>";
echo $output;
echo "<br>";

//Section to get rid of the junk before Airport ID
$cityLoc = strpos($output, $cityName);
$remove = substr($output, 0, $cityLoc); 
$len = strlen($remove);
$pos = strpos($remove, $output);
$newOutput = substr_replace($output, '', $pos, $len);

echo "<br>";

$day = date("d");
$day = strpos($newOutput, $day); //location of date
$remove = substr($newOutput, $day, strlen($day)+1); //they use 05 for single digit days
$len = $day + 2; 
$pos = strpos($remove, $newOutput);
$newOutput = substr_replace($newOutput, '', $pos, $len); //remove everything up to time of update

echo $newOutput;

$lastUpdate = strpos($newOutput, 'Z'); //find the letter Z as the times change
$remove = substr($newOutput, 0, $lastUpdate);
$lastUpdate = $remove; //this will equate to the last time the observation was updated
$date->setTimezone(new DateTimeZone('Central'));
if(date('I', time()))
{
	echo 'DST';
}
else
{
	echo 'no';
}


/*$con=mysqli_connect('localhost', 'root', 'Weather8', 'test');
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

mysqli_query($con, "INSERT INTO currentweather (Location)
	VALUES ('$setCity')");

mysqli_close($con);*/

?>

<html>
<body>
Last Update: 
<?php
	echo $lastUpdate;	
?>
</body>
</html>
