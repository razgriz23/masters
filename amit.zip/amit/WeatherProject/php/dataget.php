<?php
//this will load automatically in dataLinks.php. No need to open this page in the browser.
$cityName = 'KORD';
$data = file_get_contents('http://www.meteor.iastate.edu/~ckarsten/bufkit/data/gfsm/gfs3_kord.buf');
//$data = file_get_contents('http://www.meteor.iastate.edu/~ckarsten/bufkit/data/gfsm/gfs3_kmdw.buf');
$convert = explode("\n", $data);



?>