<!DOCTYPE html>
<html>
<body>
<?php
echo $_SERVER['HTTP_REFERER'];
?>
<h1>Editing Application</h1>

<form action="" method="post">
<strong>Weather Condition:</strong> <input type="text" name="parameter"> </br>
<strong>Weight of parameter to be used in calculation</storng> <input type="number" step="any" name="weight">
<input type="submit" name = "submit" value="Submit">
</form>

<form action="SevereWeatherModel.php">
	<input type="submit" value="Go back to home page">
</form>

<?php
include "serverconnect.php";

$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

if($post) {  //user hits submit button

	$parameter = isset($_POST["parameter"]) ? $_POST["parameter"] : '';
	$weight = isset($_POST["weight"]) ? $_POST["weight"] : '';

	$checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM parametertable"));
	$result = mysqli_query($con, "SELECT * FROM parametertable")
		or die(mysqli_error());
	$boolean = "false";

	if($checkRow < 1)	
	{
		mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
	}

	$result = mysqli_query($con, "SELECT parameter FROM parametertable WHERE parameter = '$parameter'")
			or die(mysqli_error());

	$row = mysqli_fetch_array($result);

	if($row[0] == NULL) //check to see if parameter is in table already
	{
		mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
	}
	else //parameter is in table. Update it.
	{
		mysqli_query($con, "UPDATE parametertable SET weight = '$weight' WHERE parameter = '$parameter'");
	}

	header("Location: SevereWeatherModel.php");
}
?>  

<p><u>Current List of Parameters and Weights in Database</u></p>

<?php

	$result = mysqli_query($con, "SELECT * FROM parametertable")
		or die(mysqli_error());

	$row = mysqli_fetch_array($result);
	if($result->num_rows > 0)
	{
		echo $row["parameter"] . " " . "Weight: " . $row["weight"] . "<br>";
		while($row = $result->fetch_assoc())
		{
			echo $row["parameter"] . " " . "Weight: " . $row["weight"] . "<br>";
		}
	}
	mysqli_close($con);
?>
</body>
</html>