<?php

$temperature = 0;

if($temperature <= -10 and $temperature >= -14)
{
	echo test;
}
else
{
	$temperature = 0;
}
?>