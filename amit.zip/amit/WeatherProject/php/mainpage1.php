<!DOCTYPE html>
<body>
<div id="criteria">
<?php
	 include("SevereWeatherModel.php");
?>
</div>

<div id="currentwx">
<?php 
	include("amit1.php"); 
	echo $cityName;
?>
</div>

<div id="forecast">

</div>
</body>
</html>
