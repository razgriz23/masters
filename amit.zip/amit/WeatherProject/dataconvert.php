<?php
include "dataget.php";

for ($i=0;$i<count($convert);$i++)  
{
    //echo $convert[$i].', '; //write value by index
}

$test = $convert[15];

//echo $test;
$param = (explode(" ", $test));
echo $param[0];

$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

mysqli_query($link, "INSERT INTO weatherdata (pressure, temp, wetbulb, dewpoint, thetae, winddirect, windspeed, omega) 
	VALUES ($param[0], $param[1], $param[2], $param[3], $param[4], $param[5], $param[6], $param[7])");

?>