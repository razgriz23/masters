<?php
$servername = "localhost";
$username = "root";
$password = "Weather8";

$conn = new mysqli($servername, $username, $password);
if($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

// Create database
try {
	$con = new PDO("mysql:host=$servername", $username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "CREATE DATABASE weatherproject";
	$con->exec($sql);
}

catch(PDOException $e)
{
	$e->getMessage();
}

$conn->select_db("weatherproject");
$dbname = "weatherproject";

try {

	$con = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$sql = "CREATE TABLE parametertable (
	parameter TEXT NOT NULL,
	weight FLOAT NOT NULL,
	typeofparameter TEXT NOT NULL
	)";

	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try {
	$sql = "CREATE TABLE userprofile (
	username VARCHAR(30) NOT NULL,
	password VARCHAR(30) NOT NULL
	)";
	$con->exec($sql);
}
catch(PDOException $e)
{
	echo $e->getMessage();
}

try 
{
	$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$sql = "INSERT INTO parametertable (parameter, weight, typeofparameter)
	VALUES ('Temperatures between -10 and -14', 25, 'temperature'),
	('Snow, or snow mixed with sleet ended as of 8 AM on a business day between 2 to 4 inches', 25, 'snow'),
	('Freezing rain/ice accumulations between a trace to .10 inches', 50, 'ice'),
	('Tornado Watch issued', 25, 'severe weather'),
	('Particularly Dangerous Situation(PDS) Tornado Watch issued', 75, 'severe weather'),
	('Rainfall over 1 inch', 10, 'rainfall')";
	$con->exec($sql);
}
catch(PDOException $e)
{
	$e->getMessage();
}


$con = null;
$conn->close();
?>