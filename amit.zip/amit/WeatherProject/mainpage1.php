<!DOCTYPE html>
<head>
<form action="adminpanel.php">
	<input type="submit" value="Admin Panel">
</form>
<style>
#currentwx {
	position: relative;
	left: 500px;
}
</style>
</head>
<body>

<div id="criteria">
<?php
	 include("SevereWeatherModel.php");
?>
</div>


<div id="currentwx">
<?php

include('amit1.php');


/*$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($link, "SELECT * FROM currentweather")
	or die(mysqli_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr> <th>Parameter</th> <th>Weight</th></tr>";



	?>
</div>
<div id="test">
<?php
/*print_r($_POST['weather']);
if($_POST['weather'][1] == 'current_wx')
{
		$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($link, "SELECT * FROM currentweather")
	or die(mysqli_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr> <th>Parameter</th> <th>Weight</th></tr>";

while($row = mysqli_fetch_array( $result )) {

	echo "<tr>";
		echo '<td>' . $row['cityname'] . '</td>';
		echo '<td>' . "<div class = 'bar'>". "<div style='width: 390px; div style='height: 200px;> </div>" ."</div>";
		echo "</tr>"; 
	}
}
else
{
	exit;
}*/
?>

</div>
</body>
</html>
