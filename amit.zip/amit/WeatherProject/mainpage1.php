<!DOCTYPE html>
<head>
<form action="adminpanel.php">
	<input type="submit" value="Admin Panel">
</form>
</head>
<body>
<div id="criteria">
<?php
	 include("SevereWeatherModel.php");
?>
</div>

<div id="current">
<?php 
include 'amit1.php';
?>
</div>

<div id="forecast">

</div>
</body>
</html>
