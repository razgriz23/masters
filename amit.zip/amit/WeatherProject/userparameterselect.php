<!DOCTYPE html>
<head>
</head>
<body>
<?php
include "serverconnect.php";
?> 

<p><u>Current List of Parameters and Weights in Database</u></p>
<form action = "" method = "post">
<?php


	$i = 0;
	$query = mysqli_query($con, "SELECT * FROM parametertable");
	$array = array();
	while($row = mysqli_fetch_assoc($query)){
		$array[] = $row;
		echo "<tr> <td><input type='checkbox' name='parameter' value=" . $i . "onClick=''>" . $row['parameter'] . "</td>
</tr>". "<br>";
	$i++;
	}

	



mysqli_close($con);
?>

</select>
<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';
include 'serverconnect.php';

if($post) {
  $paramter = isset($_POST["paramter"]);
  /*$checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM userpreferences"));

  $result = mysqli_query($con, "SELECT * FROM userpreferences")
  or die(mysqli_error());
  $boolean = "false";
  
  if($checkRow < 1) 
  {
    mysqli_query($con, "INSERT INTO userpreferences (cityname) 
      VALUES ('$city')");
  }
  else
  {
      mysqli_query($con, "DELETE FROM userpreferences WHERE cityname != '$city'");
      mysqli_query($con, "INSERT INTO userpreferences (cityname) 
      VALUES ('$city')");
  }
  header('Location: mainpage1.php');*/

  echo $paramter;

}
?>


</body>
</html>
