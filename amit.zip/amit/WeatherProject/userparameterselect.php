<!DOCTYPE html>
<head>
</head>
<body>
<?php
include "serverconnect.php";
?> 

<p><u>Current List of Parameters and Weights in Database</u></p>
<form action = "" method = "post">
<?php

	$i = 0;
	$query = mysqli_query($con, "SELECT * FROM parametertable");
	$array = array();
	while($row = mysqli_fetch_assoc($query)){
		$array[] = $row;
		echo "<tr> <td><input type='checkbox' name='parameter[]' value=" . $row['id'] . " onClick=''>" . $row['parameter'] . "</td>
</tr>". "<br>";
	$i++;
	}


mysqli_close($con);

if(isset($_POST['parameter'])){
  if (is_array($_POST['parameter'])) {
    foreach($_POST['parameter'] as $value){
    	$parameters[] = $value;
    }
  } else {
    $value = $_POST['parameter'];
  }
}
?>

<input type="submit" name="submit" value="Submit">
</form>

<?php

$post = isset($_POST["submit"]) ? $_POST["submit"] : '';
include 'serverconnect.php';

if($post) {
mysqli_query($con, "DELETE FROM userparameterselect");
 //mysqli_query($con, "INSERT INTO userparameterselect (parameter) 
      //VALUES ('$test')");

$arrsize = sizeof($parameters);
for($i=0; $i<$arrsize; $i++)
{
	//print_r($parameters[$i] . ' ');
	$idGet = $parameters[$i];
	$weights[] = array();
	$getInfo = mysqli_query($con, "SELECT id, parameter, weight FROM parametertable WHERE id = $idGet");
	while($row = mysqli_fetch_array( $getInfo )) {
		$id = $row['id'];
		$parameterSelected = $row['parameter'];
		$weight = $row['weight'];
		 mysqli_query($con, "INSERT INTO userparameterselect (parameter, id, weight) 
      		VALUES ('$parameterSelected', '$id', '$weight')");
		$weights[$i] = $row['weight'];
	}
}
	$arrsize1 = sizeof($weights);
	$addUp = 0;

	for($i=0; $i<$arrsize1; $i++)
	{
		$addUp += $weights[$i];
	}
	mysqli_query($con, "UPDATE userpreferences SET parameterTotal = '$addUp'");
	header('Location: mainpage1.php');
}

mysqli_close($con);
?>

</body>
</html>
