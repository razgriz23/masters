<?php
include "serverconnect.php";
?> 

<p><u>Current List of Parameters and Weights in Database</u></p>

<?php


	$i = 0;

	$query = mysqli_query($con, "SELECT * FROM parametertable");
	$array = array();
	while($row = mysqli_fetch_assoc($query)){
		$array[] = $row;
		echo "<tr> <td><input type='checkbox' name='parameter' value=" . $i . "onClick='' checked>" . $row['parameter'] . "</td>
</tr>". "<br>";
	$i++;
	}

	



mysqli_close($con);
?>
