<!DOCTYPE html>
<html>
<head>
<script>
function showBoxes(frm){
   //For each checkbox see if it has been checked, record the value.
   //day 1
   for (i = 0; i < frm.forecastday1.length; i++)
      if (frm.forecastday1[i].checked){
         message = message + frm.forecastday1[i].value + "\n";
         var id = frm.forecastday1[i];
      }
    for (i = 0; i < frm.cloudcoverday1.length; i++)
      if (frm.cloudcoverday1[i].checked){
         message = message + frm.cloudcoverday1[i].value + "\n";
         var id = frm.cloudcoverday1[i];
      }

    //day 2
    for (i = 0; i < frm.forecastday2.length; i++)
      if (frm.forecastday2[i].checked){
         message = message + frm.forecastday2[i].value + "\n";
         var id = frm.forecastday2[i];
      }
    for (i = 0; i < frm.cloudcoverday2.length; i++)
      if (frm.cloudcoverday2[i].checked){
         message = message + frm.cloudcoverday2[i].value + "\n";
         var id = frm.cloudcoverday2[i];
      }
}
</script>
</head>
<body bgcolor="#ffffff">
<form name="boxes" method = "post">
<hr size=1 noshade>
<h2>User Input Forecast</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">Day 1:</div></td>
  <td><input type="radio" name="forecastday1" value="today" onClick="" checked> Today</td>
  <td><input type="radio" name="forecastday1" value="this_afternoon" onClick="">This Afternoon</td>
  <td><input type="radio" name="forecastday1" value="tonight" onClick="">Tonight</td>
</tr>
<tr>
  <td> </td>
  <td>Temperature <input type="number" step="any" name="temperature1"></td>
</tr>
<tr>
  <td> </td>
  <td>Precip Type(if none, type none) <input type="text" name="precip1"></td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="radio" name="precipamount1" onClick="" checked><input type="number" step="any" name="precip1a"> to <input type="number" step="any" name="precip1b"> inches</td>
  <td><input type="radio" name="precipamount1" onClick="">Single input: <input type="number" step="any" name="precip1c"> inches</td>
  <td><input type="radio" name="precipamount1" value="Trace" onClick="">Trace</td>
</tr>
<tr>
  <td><div align="right">Cloud Cover:</div></td>
  <td><input type="radio" name="cloudcoverday1" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday1" value="partly" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday1" value="mostly" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday1" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td> </td>
</tr>
<tr>
  <td><div align="right">Forecast #2:</div></td>
  <td><input type="radio" name="forecastday2" value="tonight" onClick="" checked> Tonight</td>
  <td><input type="radio" name="forecastday2" value="tomorrow" onClick="">Tomorrow</td>
  <td><input type="radio" name="forecastday2" value="tomorrow_tonight" onClick="">Tomorrow Night</td>
</tr>
<tr>
<td> </td>
<td>Temperature <input type="number" step="any" name="temperature2"></td>
</tr>
<tr>
<td> </td>
<td>Precip Type(if none, type none) <input type="text" name="precip2"></td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" step="any" name="precip2a"> to <input type="number" step="any" name="precip2b"> inches</td>
  <td>Single input: <input type="number" step="any" name="precip2c"> inches</td>
</tr>
<tr>
  <td><div align="right">Cloud Cover:</div></td>
  <td><input type="radio" name="cloudcoverday2" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday2" value="partly_cloudy" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday2" value="mostly_cloudy" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday2" value="cloudy" onClick=""> Cloudy</td>
</tr>
</table>

<?php
  if(isset($_POST['forecastday1']))
  {
    $forecast1 = $_POST['forecastday1']; 
  }
  if(isset($_POST['cloudcoverday1']))
  {
    $cloudcoverday1 = $_POST['cloudcoverday1'];
  }
  if(isset($_POST['precipamount1']))
  {
    $precipAmountDay1 = $_POST['precipamount1'];
  }

  if(isset($_POST['forecastday2']))
  {
    $forecast2 = $_POST['forecastday2'];
  }
  if(isset($_POST['cloudcoverday2']))
  {
    $cloudcoverday2 = $_POST['cloudcoverday2'];
  }
 
?>
<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

include 'serverconnect.php';

if($post) {

$day1Temp = $_POST['temperature1'];
$day1PrecipType = $_POST['precip1'];
$day1PrecipAmountlow = $_POST['precip1a'];
$day1PrecipAmounthigh = $_POST['precip1b'];
$day1PrecipAmountSingle = $_POST['precip1c'];


$day2Temp = $_POST['temperature2'];
$day2PrecipType = $_POST['precip2'];
$day2PrecipAmountlow = $_POST['precip2a'];
$day2PrecipAmounthigh = $_POST['precip2b'];
$day2PrecipAmountSingle = $_POST['precip2c'];
  /*$checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM userinputforecast"));

  $result = mysqli_query($con, "SELECT * FROM userinputforecast")
  or die(mysqli_error());
  $boolean = "false";*/
  if($day1PrecipAmountSingle == NULL)
  {
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, precipamount) 
      VALUES ('$forecast1', '$cloudcoverday1', '$day1Temp', '$day1PrecipType', '$day1PrecipAmountlow', '$day1PrecipAmounthigh', '$precipAmountDay1')");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
      VALUES ('$forecast2', '$cloudcoverday2', '$day2Temp', '$day2PrecipType', '$day2PrecipAmountlow', '$day2PrecipAmounthigh')");
  //header('Location: mainpage1.php');
  }
  else
  {
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, precipamount) 
          VALUES ('$forecast1', '$cloudcoverday1', '$day1Temp', '$day1PrecipType', '$day1PrecipAmountlow', '$day1PrecipAmounthigh', '$day1PrecipAmountSingle')");
        mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
          VALUES ('$forecast2', '$cloudcoverday2', '$day2Temp', '$day2PrecipType', '$day2PrecipAmountlow', '$day2PrecipAmounthigh')");
      //header('Location: mainpage1.php');
  } 
}

mysqli_close($con);
?>
</body>
</html>