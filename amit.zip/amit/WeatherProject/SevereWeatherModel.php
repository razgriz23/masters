<?php
include 'style.html';
include 'serverconnect.php';
?>

<!DOCTYPE html>
<html>
<body>


<?php 

$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

//echo 35.74 + 0.6215*(12) - 35.75*(pow(45,0.16)) + 0.4275*(12)*(pow(45,0.16));

/*echo "Low temperature of " . -22 . " degrees Fahrenheit or colder";
mysqli_query($con, "INSERT INTO tempcriteria (Date, Time, Temperature) 
	VALUES ('2014-11-08', '09:02', 23)");*/

$result = mysqli_query($link, "SELECT * FROM parametertable")
	or die(mysqli_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr> <th>Parameter</th> <th>Weight</th></tr>";

while($row = mysqli_fetch_array( $result )) {

	echo "<tr>";
		echo '<td>' . $row['parameter'] . '</td>';
		echo '<td>' . "<div class = 'bar'>". "<div style='width: 390px; div style='height: 200px;> </div>" ."</div>";

		echo '<td>' . $row['weight'] . '</td>';
		echo '<td>' . '<a href="edit.php">Edit</a>' . '</td>';
		echo '<td>' . '<a href="delete.php?id=' . $row['id'] . '"> Delete</a></td>';
		echo "</tr>"; 
}

$userSelect = mysqli_query($link, "SELECT * FROM userparameterselect")
	or die(mysqli_error());

while($row = mysqli_fetch_array( $userSelect )) {
	echo "<tr>";
		echo '<td>' . $row['parameter'] . '</td>';
		echo "</tr>"; 
}


mysqli_close($link);


?>

</body>
</html>
