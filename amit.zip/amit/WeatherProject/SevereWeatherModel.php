<?php
include 'style.html';
include 'serverconnect.php';
?>

<!DOCTYPE html>
<html>
<head>
<?php
$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
$query = "SELECT * FROM userparameterselect";

$result = mysqli_query($link, $query) or die(mysqli_error($link));
                    
$pieData = array();
while ($row = mysqli_fetch_array($result)) {
    $param_type = $row ['parameter'];
    $weight = $row ['weight']; 
    $pieData[] = array($row['parameter'], $row['weight']); 

?>
<tbody>
    <tr>
<?php
}
?> 
                    <!--Load the AJAX API-->
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        <script type="text/javascript">

          // Load the Visualization API and the piechart package.
          google.load('visualization', '1.0', {'packages':['corechart']});

          // Set a callback to run when the Google Visualization API is loaded.
          google.setOnLoadCallback(drawChart);

          // Callback that creates and populates a data table,
          // instantiates the pie chart, passes in the data and
          // draws it.
          function drawChart() {

            // Create the data table. (and I think this is where I go wrong)
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Parameter');
            data.addColumn('number', 'weight');
            data.addRows(<?php echo json_encode($pieData, JSON_NUMERIC_CHECK); ?>);

            // Set chart options
            var options = {'title':'Closing Criteria',
                           'width':800,
                           'height':800};

            // Instantiate and draw our chart, passing in some options.
            var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
            chart.draw(data, options);
          }
        </script>
</head>
<body>


<?php 

$server = 'localhost';
$user = 'root';
$pass = 'Weather8';
$db = 'weatherproject';

$link=mysqli_connect($server, $user, $pass, $db);
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($link, "SELECT * FROM userparameterselect")
	or die(mysqli_error());

echo "<table border='1' cellpadding='10'>";
echo "<tr> <th>Parameter</th> </tr>";

while($row = mysqli_fetch_array( $result )) {

	echo "<tr>";
		echo '<td>' . $row['parameter'] . '</td>';
		echo '<td>' . '<a href="edit.php">Edit</a>' . '</td>';
		echo '<td>' . '<a href="delete.php?id=' . $row['id'] . '"> Delete</a></td>';
		echo "</tr>"; 
}	

mysqli_close($link);

?>

    <!--Div that will hold the pie chart-->
        <div id="chart_div"></div>

</body>
</html>