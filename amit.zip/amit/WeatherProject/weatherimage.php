<!DOCTYPE html>
<head>	
</head>
<body>
<?php

include 'amit1.php';

if($cloudCover == 'OVC')
{ ?>
	<img src="overcast.jpg" alt="Overcast" style="width:304px;height:228px">
<?php	
}

?>
</body>
</html>