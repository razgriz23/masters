<!DOCTYPE html>
<html>
<body>

<?php
include 'serverconnect.php';
$getCity = mysqli_query($con, "SELECT * FROM userpreferences")
  or die(mysqli_error());
$city = mysqli_fetch_array($getCity);
$cityName = $city['cityname'];
echo 'city' . $cityName;
include 'links.php';
echo "<br>";
echo "<br>";

/*substr(1, 2, 3): 
1: input string to change up
2: start position in the string
3: length. If positive, string will be returned and will contain charachters from the 
start(2 argument in substr). If negative, those characters will be omitted from the end
of the string*/
/*substr_replace(1, 2, 3, 4)
1: input string to change up
2: replacement string
3: start position
4: length
*/

date_default_timezone_set('Etc/UTC'); //ensure the time zone is set to UTC as weather stations use this notation
$url = $OHare; //default
if($cityName == 'Chicago(OHare)')
{
	$url = $OHare;
	$cityName = 'KORD';
	$timezone = 'Central';
}
else if($cityName == 'Chicago(Midway)')
{
	$url = $Midway;
	$cityName = 'KMDW';
	$timezone = 'Central';
}
else if($cityName == 'Minneapolis')
{
	$url = $Minneapolis;
	$cityName = 'KMSP';
	$timezone = 'Central';
}
else if($cityName == 'Boston')
{
	$url = $Boston;
	$cityName = 'KBOS';
	$timezone = 'East';
}

$output = file_get_contents($url);

//Section to get rid of the junk before Airport ID
$cityLoc = strpos($output, $cityName); //search output for the Airport(cityName) id
$remove = substr($output, 0, $cityLoc); 
$len = strlen($remove);
$pos = strpos($remove, $output);
$newOutput = substr_replace($output, '', $pos, $len);

//echo $newOutput;
//Airport ID is the first item in the field of text
$cityLoc = strpos($newOutput, $cityName);
$len = strlen($cityName); //determine length of the Airport ID to remove to get our date

//remove the Airport ID from the line of text. First item will be the date of observation
$remove = substr($newOutput, 0, $cityLoc); 
$newOutput = substr_replace($newOutput, '', 0, $len);
echo "<br>";
//get date of observation. First, check the time to determine the date.
//Anything before 00Z(UTC), will be day -1. Date will be in UTC on observation.
$timeLocZ = strpos($newOutput, 'Z');
$timeLoc = $timeLocZ - 4;
$time = substr($newOutput, $timeLoc, 4);
$day = substr($newOutput, 0, 3);

//remove the time and date
$newOutput = substr_replace($newOutput, '', 1, $timeLocZ + 1);

//get the wind and wind direction and gust
$knotsLoc = strpos($newOutput, 'KT');
$gustLoc = 0;
$gustLoc = strpos($newOutput, 'G');
$windDirection = substr($newOutput, 1, 3);
$windSpeed = substr($newOutput, $knotsLoc - 2, 2);

if($gustLoc == 0)
{
	$windGust = 0;
}
else
{
	$windGust = substr($newOutput, $gustLoc - 2, 2);
}

$newOutput = substr_replace($newOutput, '', 1, $knotsLoc + 1);

$smLoc = strpos($newOutput, 'SM');
$visibility = substr($newOutput, 0, $smLoc); 

$newOutput = substr_replace($newOutput, '', 1, $smLoc + 1);

//temperature and dewpoint
$slashLoc = 0;
$slashLoc = strpos($newOutput, '/');

//weather conditions
$lightLoc = 0;
$heavyLoc = 0;
$lightLoc = strpos($newOutput, '-');
$heavyLoc = strpos($newOutput, '+');

$snowLoc = 0;
$snowLoc = strpos($newOutput, 'SN');

if($lightLoc > 0 && $lightLoc < $slashLoc)
{
	$precipStrength = 'Light';
}
if($heavyLoc > 0 && $lighLoc < $slashLoc)
{
	$precipStrength = 'Heavy';
}
else
{
	$precipStrength = ' ';
}

if($snowLoc > 0 && $lightLoc < $slashLoc)
{
	$currentWeather = 'Snow';
}
else
{
	$currentWeather = 'Clear conditions';
}
//cloud cover
$fewLoc = 0;
$sctLoc = 0;
$bknLoc = 0;
$ovcLoc = 0;
$fewLoc = strpos($newOutput, 'FEW');
$sctLoc = strpos($newOutput, 'SCT');
$bknLoc = strpos($newOutput, 'BKN');
$ovcLoc = strpos($newOutput, 'OVC');

if($fewLoc == 0 && $sctLoc == 0 && $bknLoc == 0 && $ovcLoc == 0)
{
	$cloudCover = 'Clear Skies';
}
if($fewLoc > 0)
{
	$cloudCover = 'Few';
}
if($sctLoc > 0)
{
	$cloudCover = 'Scattered';
}
if($bknLoc > 0)
{
	$cloudCover = 'Broken';
}
if($ovcLoc > 0)
{
	$cloudCover = 'Overcast';
}
echo $newOutput;

//Get the wind direction. == is used in PHP for equals.
if($windDirection == 0)
{
	$windDir = "North";
}
else if($windDirection > 0 && $windDirection < 45)
{
	$windDir = "North North East";
}
else if($windDirection == 45)
{
	$windDir = "North East";
}
else if($windDirection > 45 && $windDirection < 90)
{
	$windDir = "East North East";
}
else if($windDirection == 90)
{
	$windDir = "East";
}
else if($windDirection > 90 && $windDirection < 135)
{
	$windDir = "East South East";
}
else if($windDirection == 135)
{
	$windDir = "South East";
}
else if($windDirection > 135 && $windDirection < 180)
{
	$windDir = "South South East";
}
else if($windDirection == 180)
{
	$windDir = "South";
}
else if($windDirection > 180 && $windDirection < 225)
{
	$windDir = "South South West";
}
else if($windDirection == 225)
{
	$windDir = "South West";
}
else if($windDirection > 225 && $windDirection < 270)
{
	$windDir = "West South West";
}
else if($windDirection == 270)
{
	$windDir = "West";
}
else if($windDirection > 270 && $windDirection < 315)
{
	$windDir = "West North West";
}
else if($windDirection == 315)
{
	$windDir = "North West";
}
else if($windDirection > 315 && $windDirection <= 359)
{
	$windDir = "North North West";
}

$remove = substr($newOutput, 0, $slashLoc-3); 
$newOutput = substr_replace($newOutput, '', 0, $slashLoc-3);
echo "<br>";
echo $newOutput;
$mTempLoc = strpos($newOutput, 'M');
if($mTempLoc == 0)
{
	$temperatureDegree = '-';
	$tempPosition = substr($newOutput, 0, $mTempLoc + 1);
	$temp = substr($newOutput, 1, 2);
}
else
{
	$temperatureDegree = '';
	$temp = substr($newOutput, 0, 3);
}

$slashLoc = strpos($newOutput, '/');
$remove = substr($newOutput, 0, $slashLoc+1);
$newOutput = substr_replace($newOutput, '', 0, $slashLoc+1);
$mLoc = strpos($newOutput, 'M');
if($mLoc == 0)
{
	$dewPointDegree = '-';
	$dewPointPosition = substr($newOutput, 0, $mLoc + 1);
	$dewPoint = substr($newOutput, 1, 2);
}
else
{
	$dewPointDegree = '';
	$dewPoint = substr($newOutput, 0, 3);
}
echo '<br>' . '<br>';

$altimeterLoc = strpos($newOutput, 'A');
$remove = substr($newOutput, 0, $altimeterLoc);
$newOutput = substr_replace($newOutput, '', 0, $altimeterLoc+1); //no need for the A
$nextSpace = strpos($newOutput, ' ');
$altimeter = substr($newOutput, 0, $nextSpace);

echo $newOutput;
echo '<br>';
if($cloudCover == 'Overcast')
{ ?>
	<img src="overcast.jpg" alt="Overcast" style="width:100px;height:100px">
<?php	
}
$getTime = intval($time);
$getTime = ($getTime/100);
if($timezone == 'East')
{
	$getTime = ($getTime - 5);
}
else if($timezone == 'Central')
{
	$getTime = ($getTime - 6);
}
else if($timezone == 'Mountain')
{
	$getTime = ($getTime - 7);
}
else if($timezone == 'Pacific')
{
	$getTime = ($getTime - 8);
}
else if($timezone == 'Alaskan')
{
	$getTime = ($getTime - 9);
}
else if($timezone == 'Hawaiian')
{
	$getTime = ($getTime - 10);
}

if($getTime < 0)
{
	$getTime = 12 + $getTime;
}
$getTime = number_format($getTime, 2, ':', '.');

echo "Airport ID: " . $cityName . "<br>";
echo "Last Update: " . 'Day: ' . $day . ' Time: ' . $time . 'Z ' . $getTime . ' ' . $timezone . "<br>";
echo "Current Weather: " . $precipStrength . ' ' . $currentWeather . ' with ' . $cloudCover . ' skies' . "<br>";

$currentTemp = floatval($temp);
if($mTempLoc == 0)
{
	$temperatureDegree = '-';
	$currentTempF = (($currentTemp * -1) * 1.8) + 32;
	$currentTemp = $currentTemp * -1;
}
else
{
	$currentTempF = ($currentTemp * 1.8) + 32;
}
echo "Temperature: " . $currentTempF . '°' . 'F (' . $currentTemp . '°' . 'C)'. "<br>";

$currentWindKnots = floatval($windSpeed);
$currentWindMPH = ($currentWindKnots) * (1.15078);
$currentWindMPH = round($currentWindMPH);
echo "Wind Speed: " . $windDir . ' ' . $currentWindMPH . ' mph';

$currentWindGustKnots = floatval($windGust);
$currentWindGustMPH = ($currentWindGustKnots) * (1.15078);
$currentWindGustMPH = round($currentWindGustMPH);
echo "<br>" . "Wind Gust: " . $currentWindGustMPH . ' mph';

$currentWindChill = (35.74) + (0.6215*($currentTempF)) - (35.75*(pow($currentWindMPH, 0.16))) + (0.4275*($currentTempF)*(pow($currentWindMPH, 0.16)));
$currentWindChill = number_format($currentWindChill, 2, '.', '');
echo "<br>" . "Wind Chill: " . $currentWindChill . '°' . 'F' . '<br>';

echo "Visibility: " . $visibility . ' miles' . '<br>'; 

$currentDewPoint = floatval($dewPoint);
if($mLoc == 0)
{
	$dewPointDegree = '-';
	$currentDewPointF = (($currentDewPoint * -1) * 1.8) + 32;
}
else
{
	$currentDewPointF = (($currentDewPoint * -1) * 1.8) + 32;
}

echo "Dew Point: " . $currentDewPointF . '°' . 'F' . "<br>";

$altimeter = floatval($altimeter);
echo "Altimeter: " . ($altimeter) / 100 . ' inches of mercury' . '<br>';

echo '<a href="' . $url . '" target="_blank">' . $cityName . ' Metar Source' . '</a>';

?>

</body>
</html>
