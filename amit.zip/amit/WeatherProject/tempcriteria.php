<?php
include ('forecastuserinput.html');
echo $forecast1;
echo $cloudcoverday1;
echo $forecast2;
$temperature = 0;

if($temperature <= -10 and $temperature >= -14)
{
	echo test;
}
else
{
	$temperature = 0;
}
?>