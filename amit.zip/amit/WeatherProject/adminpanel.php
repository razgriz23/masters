<html>
<head>
<title>Admin Panel</title>
</head>

<?php
(isset($_POST["weather"])) ? $cityName = $_POST["weather"] : $weather='';

?>

<body bgcolor="#ffffff">
<form action="mainpage1.php" method="post">
<hr size=1 noshade>
<h2>Admin Panel</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">What the Main Page will contain:</div></td>
  <td><input type="Checkbox" name="weather[]"  value="closing_criteria" onClick="" checked>Closing Criteria</td>
  <td><input type="Checkbox" name="weather[]"  value="current_wx"   onClick="">Current Weather</td>
  <td><input type="Checkbox" name="weather[]"  value="forecast"      onClick="" checked>Forecast</td>
</tr>
<tr>
  <td><div align="right">Forecast Source:</div></td>
  <td><input type="radio" name="forecasttype" value="userinput" onClick="" checked> User Input</td>
  <td><input type="radio" name="forecasttype" value="fromnws" onClick="">From National Weather Service</td>
  <td><input type="radio" name="forecasttype" value="fromapp" onClick="">From Application</td>
</tr>
</table>
<p>
  <input type="submit" value="Submit Changes">
</p>
</form>


<form action = "" method = "post">
<select id="cityName" name="cityName">
<option value = ' '> Please Select A City </option>
<option value = 'Chicago(OHare)'> Chicago(OHare)</option>
<option value = 'Chicago(Midway)'> Chicago(Midway)</option>
<option value = 'DeKalb, IL'> DeKalb, IL</option>
<option value = 'Minneapolis'> Minneapolis</option>
<option value = 'Boston'> Boston</option>
<option value = 'Honolulu,HI'> Honolulu,HI</option>
</select>
<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';
include 'serverconnect.php';

if($post) {
  $city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
  $checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM userpreferences"));

  $result = mysqli_query($con, "SELECT * FROM userpreferences")
  or die(mysqli_error());
  $boolean = "false";
  
  if($checkRow < 1) 
  {
    mysqli_query($con, "INSERT INTO userpreferences (cityname) 
      VALUES ('$city')");
  }
  else
  {
      mysqli_query($con, "DELETE FROM userpreferences WHERE cityname != '$city'");
      mysqli_query($con, "INSERT INTO userpreferences (cityname) 
      VALUES ('$city')");
  }
  header('Location: mainpage1.php');

}
?>

</body>
</html>
