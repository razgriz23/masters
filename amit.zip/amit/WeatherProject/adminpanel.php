<html>
<head>
<title>Admin Panel</title>
<SCRIPT LANGUAGE="JavaScript">
<!--
function showBoxes(frm){
   var message = "Your chose:\n\n"

   //For each checkbox see if it has been checked, record the value.
   for (i = 0; i < frm.weather.length; i++)
      if (frm.weather[i].checked){
         message = message + frm.weather[i].value + "\n";
      }
   for (i = 0; i < frm.forecasttype.length; i++)
      if (frm.forecasttype[i].checked){
         message = message + frm.forecasttype[i].value + "\n";
      }

     if(frm.weather[0].checked)
     {
     	alert("test");
     	//change to page that contains what user wants
     	document.location.href = 'mainpage1.php';
     }
     alert(message);
}

//NOTE THE onClick="" empty event handlers in the checkbox and radio input fields below
//are there to fix a bug in Netscape 2.0X. Placing an onClick handler in imput fields fixes
//a bug where input objects inside tables are reflected more than once.

//-->
</script>
</head>
<body bgcolor="#ffffff">
<form name="boxes">
<hr size=1 noshade>
<h2>Admin Panel</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">What the Main Page will contain:</div></td>
  <td><input type="Checkbox" name="weather"  value="closing_criteria" onClick="" checked>Closing Criteria</td>
  <td><input type="Checkbox" name="weather"  value="current_wx"   onClick="">Current Weather</td>
  <td><input type="Checkbox" name="weather"  value="forecast"      onClick="" checked>Forecast</td>
</tr>
<tr>
	<td><div align="right">Forecast Source:</div></td>
	<td><input type="radio" name="forecasttype" value="userinput" onClick="" checked> User Input</td>
	<td><input type="radio" name="forecasttype" value="fromnws" onClick="">From National Weather Service</td>
	<td><input type="radio" name="forecasttype" value="fromapp" onClick="">From Application</td>
</tr>
</table>
<p>
<input type="Button" value="Submit Changes" onClick="showBoxes(this.form);">
</p>
</form>


<?php
(isset($_POST["cityName"])) ? $cityName = $_POST["cityName"] : $cityName='';

?>

<form action = "mainpage1.php" method = "post">
<select id="cityName" name="cityName">
<option value = ' '> Please Select A City </option>
<option value = 'Chicago(OHare)'> Chicago(OHare)</option>
<option value = 'Chicago(Midway)'> Chicago(Midway)</option>
<option value = 'Minneapolis'> Minneapolis</option>
<option value = 'Boston'> Boston</option>
</select>
<input type="submit" value="Submit">
</form>

</body>
</html>
