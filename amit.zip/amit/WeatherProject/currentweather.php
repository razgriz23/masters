<?php
include 'adminpanel.html';

$city = $cityName;

?>