<!DOCTYPE html>
<html>
<body>

<h1>Editing Application</h1>

<form action="" method="post">
<strong>Weather Condition:</strong> <input type="text" name="parameter"> </br>
<strong>Weight of parameter to be used in calculation</storng> <input type="number" step="any" name="weight">
<input type="submit" name = "submit" value="Submit">
</form>

<?php
include "serverconnect.php";

$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

if($post) {

$parameter = isset($_POST["parameter"]) ? $_POST["parameter"] : '';
$weight = isset($_POST["weight"]) ? $_POST["weight"] : '';

$checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM parametertable"));
$result = mysqli_query($con, "SELECT * FROM parametertable")
	or die(mysqli_error());
$boolean = "false";
echo $checkRow;

if($checkRow < 1)
{
	mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
}
echo $parameter;

$result = mysqli_query($con, "SELECT parameter FROM parametertable WHERE parameter = '$parameter'")
			or die(mysqli_error());

$row = mysqli_fetch_array($result);

if($row[0] == NULL)
{
	mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
}
else 
{
	mysqli_query($con, "UPDATE parametertable SET weight = '$weight' WHERE parameter = '$parameter'");
}


mysqli_close($con);
header("Location: SevereWeatherModel.php");
}
?>  


</body>
</html>