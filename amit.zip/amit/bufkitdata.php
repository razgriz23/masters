<?php

$url = 'http://www.meteor.iastate.edu/~ckarsten/bufkit/data/nam/nam_kord.buf';
$output = file_get_contents($url);

echo $output;


?>