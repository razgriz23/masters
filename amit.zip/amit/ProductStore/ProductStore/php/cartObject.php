<?php
	class cartObject
	{
		private $productId;
		private $quantity;

		public function getProductId()
		{
			return $this->productId;
		}

		public function setProductId($id)
		{
			$this->productId = $id;
		}

		public function getQuantity()
		{
			return $this->quantity;
		}

		public function setQuantity($q)
		{
			$this->quantity = $q;
		}
	}
?>