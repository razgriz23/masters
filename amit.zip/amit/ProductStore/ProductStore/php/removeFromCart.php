<?php  
	include 'cartObject.php';
	session_start();
	$total = 0;

	foreach ($_SESSION['cartProducts'] as $i=>$p)
	{
		if ($p->getProductId() == $_POST['productId'])
		{
			unset($_SESSION['cartProducts'][$i]);
		}

		else
		{
			$total = $total + $p->getQuantity();
		}
	}
	$_SESSION['itemsInCart'] = $total;
	header('Location: myCart.php');
?>