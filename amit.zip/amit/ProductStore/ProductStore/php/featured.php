<section class="featured">
	<button class="left"></button>
	<div class="featuredImages">
		<img src="" alt="">
		<img src="" alt="">
		<img src="" alt="">
		<img src="" alt="">
		<img class="featuredHidden" src="" alt="">
		<img class="featuredHidden" src="" alt="">
		<img class="featuredHidden" src="" alt="">
		<img class="featuredHidden" src="" alt="">
	</div>
	<button class="right"></button>
</section>