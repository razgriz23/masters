<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/index.css">
    </head>
    <body>
    	<div class="wrapper">
    		
    		<?php include 'header.php' ?>
            <?php include 'connect.php' ?>

            <section class="registrationForm">
                <h3>Create Your Account</h3>
                <form class="register" action="registerUser.php" method="post">
                    <h4>First Name</h4>
                    <input type="text" name="firstName">

                    <h4>Last Name</h4>
                    <input type="text" name="lastName">

                    <h4>Password</h4>
                    <input type="password" name="password">

                    <h4>Please re-enter your password</h4>
                    <input type="password" name="password2">

                    <h4>Address</h4>
                    <input type="text" name="address">

                    <h4>Phone Number</h4>
                    <input type="text" name="phoneNumber">

                    <h4>Email</h4>
                    <input type="text" name="email">

                    <section>
                        <input class="submit-button" type="submit" value="Submit">
                        <input class="reset-button" type="reset" value="Reset">
                    </section>
                </form>
            </section>

        	<?php include 'footer.php' ?>

    	</div>
    	
    </body>
</html>