<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/index.css">
    </head>
    <body>
    	<div class="wrapper">
            <!-- if (session_status() == PHP_SESSION_NONE) //session_id() == '' in PHP < 5.4.0 -->
            <?php require 'connect.php' ?>
    		<?php include 'header.php'; include 'shoppingCart.php'; ?>

	    	<?php 
                $imagePath = '../img/categories/';
                try
                {
                    $pdo = new PDO($con, USER, PASSWORD);

                    $sql = "SELECT * FROM products WHERE productId = ?";
                    $statement = $pdo->prepare($sql);
                    $statement->bindValue(1, $_GET['productId']);
                    $statement->execute();
                    $row = $statement->fetch();

                    $category = $row['category'];

                    if (!empty($row))
                    {
                        echo "<div>";
                        echo "<h3>" . $row['productName'] . "</h3>";
                        echo "<img src=" . $imagePath . $category . '/' . $row['imageName'] . " alt=\"\">";
                        echo "<p>" . $row['description'] .  "</p>";
                        echo "</div>";
                    }

                    else
                    {
                        echo "Error retrieving data from the Database...";
                    }

                    $pdo = null;
                }

                catch(PDOException $e)
                {
                    echo "Connection failed: " . $e->getMessage();
                }
            ?>

            <?php include 'footer.php'; ?>

    	</div>
    	

    </body>
</html>