<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/index.css">
    </head>
    <body>
    	<div class="wrapper">
    		
    		<?php include('header.php'); ?>

    		<div class="categorizedImages">
    			<?php 
    				require 'connect.php';

    				$imagePath = '../img/categories/' . $_POST['categories'] . '/';

    				try
    				{
    					$pdo = new PDO($con, USER, PASSWORD);

	    				$sql = "SELECT * FROM products WHERE category = ?";

	    				$statement = $pdo->prepare($sql);
	    				$statement->bindValue(1, $_POST['categories']);
	    				$statement->execute();
	    				$rows = $statement->fetchAll(PDO::FETCH_ASSOC);

	    				if (!empty($rows))
	    				{
	    					foreach($rows as $row)
	    					{
	    						echo "<div>";
	    						echo "<h3>" . $row["productName"] . "</h3>";
	    						echo "<a href=productDetail.php?productId=" . $row['productId'] . ">";
	    						echo "<img src=" . $imagePath . $row['imageName'] . " alt=\"\">";
	    						echo "</a>";

	    						if ($row['quantity'] > 0)
                                {
                                    //echo "<h4>" . $row['quantity'] . "</h4>";
                                    echo "<h4>In stock</h4>";
                                }

                                else
                                {
                                    echo "<h4>Currently out of stock</h4>";
                                }

	    						echo "</div>";
	    					}
	    				}

	    				else
	    				{
	    					echo "Error retrieving data from the Database...";
	    				}

	    				$pdo = null;
    				}

    				catch (PDOException $e)
    				{
    					echo 'Connection failed ' . $e->getMessage();
    				}
    				
    			?>
    		</div>

    	</div>
    </body>
</html>