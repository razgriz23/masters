<?php
	include 'cartObject.php';
	session_start();	
	if (session_id() != '' && isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true)
	{
		$_SESSION['loginToViewCart'] = false;

		//add item to cart via session
		$_SESSION['itemsInCart'] = $_SESSION['itemsInCart'] + $_POST['quantity'];
		
		$cartObject = new cartObject;
		$cartObject->setProductId($_POST['productId']);
		$cartObject->setQuantity($_POST['quantity']);
		array_push($_SESSION['cartProducts'], $cartObject);
		header('Location: index.php');
	}

	else
	{
		$_SESSION['loginToViewCart'] = true;
		$_SESSION['loggedIn'] = false;
		$_SESSION['loginIncorrect'] = false;
		$_SESSION['loginEmpty'] = false;
		header('Location: index.php');
	}
?>