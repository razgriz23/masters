<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/index.css">
    </head>
    <body>

    	<div class="wrapper">
    		<?php include 'header.php' ?>
            <?php include 'connect.php' ?>

            <section class="signInForm">
                <h3>Sign in to your account to view your cart</h3>
                <form class="signIn" action="userLogin.php" method="post">
                	<h4>Email</h4>
                	<input type="text" name="userEmail">

                	<h4>Password</h4>
					<input type="text" name="userPassword">

					<section>
						<input class="submit-button" type="submit" value="Submit">
					</section>
                </form>
            </section>

            <?php 
	            /* Login Error Messages */
				if (isset($_SESSION['loginIncorrect']) && $_SESSION['loginIncorrect'] == true)
				{
					echo "<p class=\"loginError\">Incorrect credentials</p>";
				}

				else if (isset($_SESSION['loginEmpty']) && $_SESSION['loginEmpty'] == true)
				{
					echo "<p class=\"loginError\">No value was entered</p>";
				}
			?>

            <?php include 'footer.php'; ?>
    	</div>

    </body>
</html>