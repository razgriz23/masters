<?php
	session_start();
	if (!empty($_POST['userEmail']) || !empty($_POST['userPassword']))
	{
		require 'connect.php';

		try
		{
			$pdo = new PDO($con, USER, PASSWORD);
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			$sql = "SELECT * FROM users WHERE email = ? AND password = ?";

			$statement = $pdo->prepare($sql);
			$statement->bindValue(1, $_POST['userEmail']);
			$statement->bindValue(2, $_POST['userPassword']);
			$statement->execute();
			$row = $statement->fetch();

			if (!empty($row))
			{
				$_SESSION['loggedIn'] = true;
				$_SESSION['loginIncorrect'] = false;
				$_SESSION['loginEmpty'] = false;
				$_SESSION['loginToViewCart'] = false;
				$_SESSION['itemsInCart'] = 0;
				$_SESSION['cartProducts'] = array();
				$_SESSION['userName'] = $row['email'];
				$pdo = null;
				header('Location: index.php');
			}

			else
			{
				$_SESSION['loginIncorrect'] = true;
				$_SESSION['loginEmpty'] = false;
				$_SESSION['loginToViewCart'] = false;
				$pdo = null;
				header('Location: index.php');
			}
		}
		catch (PDOException $e)
		{
			echo "Connection failed: " . $e->getMessage();
		}

	}

	else
	{
		$_SESSION['loginEmpty'] = true;
		$_SESSION['loginIncorrect'] = false;
		$_SESSION['loginToViewCart'] = false;
		header('Location: index.php');
	}
?>