<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/index.css">
    </head>
    <body>
    	<div class="wrapper myCart">
    		<?php include 'cartObject.php'; include 'header.php'; ?>
    		<?php
    			//include 'cartObject.php';
    			//session_start();
    			require 'connect.php';
    			echo "<div class=\"cartProducts\">";
    			if (session_id() != '' && isset($_SESSION['itemsInCart']) && $_SESSION['itemsInCart'] > 0)
    			{
    				$items = $_SESSION['itemsInCart'];
    				$msg = $items > 1 ? 'There are ' . $items . ' items in your cart.' : 'There is 1 item in your cart';
    				echo "<h3>" . $msg . "</h3>";

    				try
    				{
    					foreach($_SESSION['cartProducts'] as $p)
    					{
    						$pdo = new PDO($con, USER, PASSWORD);

	    					$sql = "SELECT * FROM products WHERE productId = ?";

	    					$statement = $pdo->prepare($sql);
	    					$statement->bindValue(1, $p->getProductId());
	    					$statement->execute();
	    					$row = $statement->fetch();

	    					if (!empty($row))
	    					{
	    						$imagePath = '../img/categories/';
	    						echo "<div class=\"cartProduct\">";
	    						echo "<h4>" . $row['productName'] . ' x ' . $p->getQuantity() . "</h4>";
	    						echo "<img src=" . $imagePath . $row['category'] . '/' . $row['imageName'] . ">";
	    						echo "<form action=\"removeFromCart.php\" method=\"post\">";
	    						echo "<input class=\"remove\" type=\"submit\" value=\"Remove\">";
	    						echo "<input style=\"display: none;\" type=\"text\" name=\"productId\" value=" . $row['productId'] . ">";
	    						echo "</form>";
	    						echo "</div>";
	    					}
    					}
    				}

    				catch (PDOException $e)
    				{
    					echo 'Connection failed: ' . $e->getMessage();
    				}
    			}

    			else
    			{
    				echo "<h3>There are no items in your cart</h3>";
    			}
    			echo "</div>";
    			include 'footer.php';
    		?>
    	</div>

    </body>
</html>