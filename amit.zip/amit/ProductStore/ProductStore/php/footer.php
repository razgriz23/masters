<footer>
	&copy; All rights reserved
</footer>