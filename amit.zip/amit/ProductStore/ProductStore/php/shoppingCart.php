<section class="shoppingCart">
    <!-- <h3>Shopping Cart</h3> -->
    <?php
	    try
	    {
	        $pdo = new PDO($con, USER, PASSWORD);

	        $sql = "SELECT * FROM products WHERE productId = ?";
	        $statement = $pdo->prepare($sql);
	        $statement->bindValue(1, $_GET['productId']);
	        $statement->execute();
	        $row = $statement->fetch();

	        if (!empty($row))
	        {
	        	echo "<h4>" . $row['productName'] . "</h4>";
	        	echo "<h5>" . "$" . $row['price'] . "</h5>";
	            $quantity = $row['quantity'];

		    	if ($quantity > 0)
		    	{
		    		echo "<form action=\"addToCart.php\" method=\"post\">";
		    		echo "<input style=\"display: none;\" type=\"text\" name=\"productId\" value=" . $_GET['productId'] . ">";
		    		echo "Quantity: <select name=\"quantity\">";
		    		for ($i = 0; $i < $quantity; $i++)
		    		{
		    			echo "<option value=" . ($i + 1) . ">";
		    			echo ($i + 1);
		    			echo "</option>";
		    		}
		    		echo "</select>";

		    		echo "<br />";
			    	echo "<input class=\"submit-button\" type=\"submit\" value=\"Add To Cart\">";
			    	echo "</form>";
		    	}

		    	else
		    	{
		    		echo "We're sorry, this item is currently out of stock.";	
		    	}		    	
			 }

	        else
	        {
	            echo "Error retrieving data from the Database...";
	        }

	        $pdo = null;
	    }

	    catch (PDOException $e)
	    {
	    	echo "Connection failed: " . $e->getMessage();
	    }
    ?>
</section>