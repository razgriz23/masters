<?php 
	require 'connect.php';

	$firstName = $_POST["firstName"];
	$lastName = $_POST["lastName"];
	$password = $_POST["password"];
	$address = $_POST["address"];
	$phoneNumber = $_POST["phoneNumber"];
	$email = $_POST["email"];

	/*if (isset($firstName), isset($lastName), isset($password), isset($address), isset($phoneNumber), isset($email))
	{
		echo "<script>alert('everything is set');</script>";
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
		{
		   $emailErr = "Invalid email format";
		   echo $emailErr;
		}
	}

	else
	{
		//echo ;
	}*/

	try
	{
		$pdo = new PDO($con, USER, PASSWORD);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	

		$sql = "INSERT INTO users (firstName, lastName, password, address, phoneNumber, email)
	        VALUES (?, ?, ?, ?, ?, ?)";

		$statement = $pdo->prepare($sql);
		$statement->bindValue(1, $_POST["firstName"]);
		$statement->bindValue(2, $_POST["lastName"]);
		$statement->bindValue(3, $_POST["password"]);
		$statement->bindValue(4, $_POST["address"]);
		$statement->bindValue(5, $_POST["phoneNumber"]);
		$statement->bindValue(6, $_POST["email"]);
		$statement->execute();	
	}

	catch (PDOException $e)
	{
		echo 'Connection failed ' . $e->getMessage();
	}

	session_start();
	$_SESSION['loggedIn'] = true;
	$_SESSION['userName'] = $_POST["email"];
	$pdo = null;
	header('Location: index.php');
?>