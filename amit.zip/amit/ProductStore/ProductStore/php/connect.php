<?php 

	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASSWORD', 'Weather8');
	define('DB', 'productstore');

	$con = "mysql:host=" . HOST . ";dbname=" . DB;

?>