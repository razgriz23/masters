$(function(){
	var cats = ['../img/featured/book.gif', '../img/featured/clothes.gif', '../img/featured/computer.gif', 
			    '../img/featured/education.gif', '../img/featured/bunny.jpg', '../img/featured/tiger.jpg', 
			    '../img/featured/kitten.jpg', '../img/featured/monkey.jpg'];
				
	var arr = shuffleArray(cats);

	$('section.featured div.featuredImages img').each(function(i){
		if ( !$(this).hasClass('featuredHidden'))
		{
			$(this).attr('src', arr[i]);
			$(this).fadeTo(1000, 1);
		}
		else
		{
			$(this).attr('src', arr[i]);
		}
	});
});

function shuffleArray(array)
{
	for (var i = array.length - 1; i > 0; i--) 
	{
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
	}
	return array;
}

// Carousel Move Left
$('section.featured button.left').bind("click", function(){
	//first get a copy of all the image srcs
	var originalArray = [];
	var imgArray = [];
	$('section.featured div.featuredImages img').each(function(){
		originalArray.push($(this).attr('src'));
		imgArray.push($(this).attr('src'));
	});

	var numOfImgs = $('section.featured div.featuredImages').children().length;

	for (var i = 0; i < imgArray.length; i++) {

		if (i == 0) 
		{
			var temp = originalArray[i];
			originalArray[i] = imgArray[4];
			originalArray[4] = temp;
		}

		if ( !$(this).hasClass('featuredHidden') )
		{
			originalArray[i] = imgArray[i + 1];
		}

		if ( $(this).hasClass('featuredHidden') )
		{
			originalArray[i] = imgArray[i - 1];
		}

		if (i == (numOfImgs - 1)) {
			var temp = imgArray[0];
			originalArray[numOfImgs - 1] = temp;
		}
	}
	$('section.featured div.featuredImages img').each(function(i){
		$(this).attr('src', originalArray[i]);	
	});
});

//Carousel Move Right
$('section.featured button.right').bind('click', function(){
	//first get a copy of all the image srcs
	var originalArray = [];
	var imgArray = [];
	$('section.featured div.featuredImages img').each(function(){
		originalArray.push($(this).attr('src'));
		imgArray.push($(this).attr('src'));
	});

	var numOfImgs = $('section.featured div.featuredImages').children().length;

	for (var i = 0; i < imgArray.length; i++) {



		if ( !$(this).hasClass('featuredHidden') )
		{
			originalArray[i] = imgArray[i - 1];
		}

		if ( $(this).hasClass('featuredHidden') )
		{
			originalArray[i] = imgArray[i + 1];
		}

		originalArray[0] = imgArray[numOfImgs - 1];
	}

	$('section.featured div.featuredImages img').each(function(i){
		$(this).attr('src', originalArray[i]);
	});
});