<!DOCTYPE html>
<? ob_start(); ?>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  background-color: #b0c4de;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  display: inline;
}
</style>
<ul>
  <li><a href="index.php">Main Page</a></li>
  <li><a href="adminpanel.php">Admin Panel</a></li>
  <li><a href="edit.php">Add/Edit A Parameter</a></li>
  <li><a href="forecastuserinput.php">Enter Own Forecast</a></li>
</ul>
</head>
<body>
<?php
include "serverconnect.php";
?> 

<p><u>Current List of Parameters and Weights in Database</u></p>
<form action = "" method = "post">
<?php
	$i = 0;
	$query = mysqli_query($con, "SELECT * FROM parametertable");
	$array = array();
	while($row = mysqli_fetch_assoc($query)){
		$array[] = $row;
		echo "<tr>";
		echo '<td>' . "<input type='checkbox' name='parameter[]' value=" . $row['id'] . " onClick=''>" . $row['parameter'] . '</td>';
		echo '<br>';
		echo "</tr>"; 
	$i++;
	}
if(isset($_POST['parameter'])){
  if (is_array($_POST['parameter'])) {
    foreach($_POST['parameter'] as $value){
    	$parameters[] = $value;
    }
  } else {
    $value = $_POST['parameter'];
  }
}
?>

<input type="submit" name="submit" value="Submit">
</form>
<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';
if($post) {
mysqli_query($con, "DELETE FROM userparameterselect");
$arrsize = sizeof($parameters);
for($i=0; $i<$arrsize; $i++)
{
	$idGet = $parameters[$i];
	$weights[] = array();
	$getInfo = mysqli_query($con, "SELECT id, parameter, weight FROM parametertable WHERE id = $idGet");
	while($row = mysqli_fetch_array( $getInfo )) {
		$id = $row['id'];
		$parameterSelected = $row['parameter'];
		$weight = $row['weight'];
		 mysqli_query($con, "INSERT INTO userparameterselect (parameter, id, weight) 
      		VALUES ('$parameterSelected', '$id', '$weight')");
		$weights[$i] = $row['weight'];
	}
}
	$arrsize1 = sizeof($weights);
	$addUp = 0;
	for($i=0; $i<$arrsize1; $i++)
	{
		$addUp += $weights[$i];
	}
	mysqli_query($con, "UPDATE userpreferences SET parameterTotal = '$addUp'");
	mysqli_close($con);
	header('Location: index.php');
}
?>
<? ob_flush(); ?>
</body>
</html>
