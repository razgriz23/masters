<html>
<head>
<title>Admin Panel</title>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: red;
}

#selection {
  float: left;
}
</style>
<ul>
  <li><a href="index.php">Main Page</a></li>
  <li><a href="edit.php">Add/Edit A Parameter</a></li>
  <li><a href="forecastuserinput.php">Enter Own Forecast</a></li>
  <li><a href="userparameterselect.php">Select Parameters</a></li>
  <li><a href="faq.html">FAQ</a></li>
</ul>
</head>

<body>


<div id="selection">
<body bgcolor="#ffffff">
<form action=" " method="post">
<hr size=1 noshade>
<h2>Admin Panel</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">What the Main Page will contain:</div></td>
  <td><input type="Checkbox" name="weather[]"  value="closing_criteria" onClick="" checked>Closing Criteria</td>
  <td><input type="Checkbox" name="weather[]"  value="current_wx"   onClick="" checked>Current Weather</td>
  <td><input type="Checkbox" name="weather[]"  value="forecast"      onClick="" checked>Forecast</td>
</tr>
<tr>
  <td><div align="right">Forecast Source:</div></td>
  <td><input type="radio" name="forecasttype" value="userinput" onClick="" checked> User Input</td>
</tr>
</table>
<p>
  <input type="submit" name="submit1" value="Submit Changes">
</p>
</form>
<?php
include 'serverconnect.php';
$post = isset($_POST["submit1"]) ? $_POST["submit1"] : '';
if($post) {    
$mainpage = isset($_POST["weather"]) ? $_POST["weather"] : 'current_wx';
$forecasttype = isset($_POST['forecasttype']) ? $_POST['forecasttype'] : '';

$mainpage = implode(" ", $mainpage);

mysqli_query($con, "UPDATE userpreferences SET mainpagewxlook = '$mainpage'");
header('Location: index.php');
}
?>

<form action = "" method = "post">
<select id="cityName" name="cityName">
<option value = ' '> Please Select A City </option>
<option value = 'Chicago(OHare)'> Chicago(OHare)</option>
<option value = 'Chicago(Midway)'> Chicago(Midway)</option>
<option value = 'DeKalb, IL'> DeKalb, IL</option>
<option value = 'Minneapolis'> Minneapolis</option>
<option value = 'Boston'> Boston</option>
<option value = 'Honolulu,HI'> Honolulu,HI</option>
</select>
<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

if($post) {
  $city = isset($_POST["cityName"]) ? $_POST["cityName"] : 'KORD';
  $checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM userpreferences"));

  $result = mysqli_query($con, "SELECT * FROM userpreferences")
  or die(mysqli_error());
  $boolean = "false";
  
  if($checkRow < 1) 
  {
    mysqli_query($con, "INSERT INTO userpreferences (cityname) 
      VALUES ('$city')");
  }
  else
  {
      mysqli_query($con, "UPDATE userpreferences SET cityname = '$city' WHERE cityname != '$city'");
  }
  header('Location: index.php');

}
?>

</div>
</body>
</html>
