<!DOCTYPE html>
<? ob_start(); ?>
<html>
<head>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;  
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a:link, a:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a:hover, a:active {
    background-color: #7A991A;
}

#forecast {
  float: left;
}
</style>
<ul>
  <li><a href="index.php">Main Page</a></li>
  <li><a href="adminpanel.php">Admin Panel</a></li>
  <li><a href="edit.php">Add/Edit A Parameter</a></li>
  <li><a href="userparameterselect.php">Select Parameters</a></li>
</ul>
<script>
function showBoxes(frm){
   //For each checkbox see if it has been checked, record the value.
   //day 1
   for (i = 0; i < frm.forecastday1.length; i++)
      if (frm.forecastday1[i].checked){
         message = message + frm.forecastday1[i].value + "\n";
         var id = frm.forecastday1[i];
      }
    for (i = 0; i < frm.cloudcoverday1.length; i++)
      if (frm.cloudcoverday1[i].checked){
         message = message + frm.cloudcoverday1[i].value + "\n";
         var id = frm.cloudcoverday1[i];
      }

    //day 2
    for (i = 0; i < frm.forecastday2.length; i++)
      if (frm.forecastday2[i].checked){
         message = message + frm.forecastday2[i].value + "\n";
         var id = frm.forecastday2[i];
      }
    for (i = 0; i < frm.cloudcoverday2.length; i++)
      if (frm.cloudcoverday2[i].checked){
         message = message + frm.cloudcoverday2[i].value + "\n";
         var id = frm.cloudcoverday2[i];
      }
}
</script>
</head>

<body bgcolor="#ffffff">
<div id="forecast">
<form name="boxes" method = "post">
<hr size=1 noshade>
<h2>User Input Forecast</h2>
<table border="1" CellSpacing="0" CellPadding="6">
<tr>
  <td><div align="right">Day 1:</div></td>
  <td><input type="radio" name="forecastday1" value="today" onClick="" checked> Today</td>
  <td><input type="radio" name="forecastday1" value="this_afternoon" onClick="">This Afternoon</td>
  <td><input type="radio" name="forecastday1" value="tonight" onClick="">Tonight</td>
</tr>
<tr>
  <td> </td>
  <td>Temperature <input type="number" step="any" name="temperature1"></td>
</tr>
<tr>
  <td> </td>
  <td>Precip Type(if none, type none) <input type="text" name="precip1"></td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="radio" name="precipamount1" onClick="" checked><input type="number" step="any" name="precip1a"> to <input type="number" step="any" name="precip1b"> inches</td>
  <td><input type="radio" name="precipamount1" onClick="">Single input: <input type="number" step="any" name="precip1c"> inches</td>
  <td><input type="radio" name="precipamount1" value="Trace" onClick="">Trace</td>
</tr>
<tr>
  <td><div align="right">Cloud Cover:</div></td>
  <td><input type="radio" name="cloudcoverday1" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday1" value="partly" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday1" value="mostly" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday1" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td> </td>
</tr>
<tr>
  <td> </td>
</tr>
<tr>
  <td><div align="right">Forecast #2:</div></td>
  <td><input type="radio" name="forecastday2" value="tonight" onClick="" checked> Tonight</td>
  <td><input type="radio" name="forecastday2" value="tomorrow" onClick="">Tomorrow</td>
  <td><input type="radio" name="forecastday2" value="tomorrow_tonight" onClick="">Tomorrow Night</td>
</tr>
<tr>
<td> </td>
<td>Temperature <input type="number" step="any" name="temperature2"></td>
</tr>
<tr>
<td> </td>
<td>Precip Type(if none, type none) <input type="text" name="precip2"></td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" step="any" name="precip2a"> to <input type="number" step="any" name="precip2b"> inches</td>
  <td>Single input: <input type="number" step="any" name="precip2c"> inches</td>
</tr>
<tr>
  <td><div align="right">Cloud Cover:</div></td>
  <td><input type="radio" name="cloudcoverday2" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday2" value="partly_cloudy" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday2" value="mostly_cloudy" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday2" value="cloudy" onClick=""> Cloudy</td>
</tr>
<tr>
  <td> </td>
</tr>
<tr>
  <td> </td>
</tr>
<tr>
  <td><div align="right">Forecast #3:</div></td>
  <td><input type="radio" name="forecastday3" value="Monday" onClick="" checked> Monday</td>
  <td><input type="radio" name="forecastday3" value="Tuesday" onClick="">Tuesday</td>
  <td><input type="radio" name="forecastday3" value="Wednesday" onClick="">Wednesday</td>
  <td><input type="radio" name="forecastday3" value="Thursday" onClick=""> Thursday</td>
  <td><input type="radio" name="forecastday3" value="Friday" onClick="">Friday</td>
  <td><input type="radio" name="forecastday3" value="Saturday" onClick="">Saturday</td>
  <td><input type="radio" name="forecastday3" value="Sunday" onClick="">Sunday</td>
</tr>
<tr>
<td> </td>
<td>Temperature <input type="number" step="any" name="temperature3"></td>
</tr>
<tr>
<td> </td>
<td>Precip Type(if none, type none) <input type="text" name="precip3"></td>
</tr>
<tr>
  <td>Precip Amount:</td>
  <td><input type="number" step="any" name="precip3a"> to <input type="number" step="any" name="precip3b"> inches</td>
  <td>Single input: <input type="number" step="any" name="precip3c"> inches</td>
</tr>
<tr>
  <td><div align="right">Cloud Cover:</div></td>
  <td><input type="radio" name="cloudcoverday3" value="clear_skies" onClick="" checked> Clear Skies</td>
  <td><input type="radio" name="cloudcoverday3" value="partly_cloudy" onClick=""> Partly Cloudy</td>
  <td><input type="radio" name="cloudcoverday3" value="mostly_cloudy" onClick=""> Mostly Cloudy</td>
  <td><input type="radio" name="cloudcoverday3" value="cloudy" onClick=""> Cloudy</td>
</tr>
</table>

<?php
  if(isset($_POST['forecastday1']))
  {
    $forecast1 = $_POST['forecastday1']; 
  }
  if(isset($_POST['cloudcoverday1']))
  {
    $cloudcoverday1 = $_POST['cloudcoverday1'];
  }
  if(isset($_POST['precipamount1']))
  {
    $precipAmountDay1 = $_POST['precipamount1'];
  }

  if(isset($_POST['forecastday2']))
  {
    $forecast2 = $_POST['forecastday2'];
  }
  if(isset($_POST['cloudcoverday2']))
  {
    $cloudcoverday2 = $_POST['cloudcoverday2'];
  }

  if(isset($_POST['forecastday3']))
  {
    $forecast3 = $_POST['forecastday3'];
  }
  if(isset($_POST['cloudcoverday3']))
  {
    $cloudcoverday3 = $_POST['cloudcoverday3'];
  }
 
?>
<input type="submit" name="submit" value="Submit">
</form>

<?php
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';

include 'serverconnect.php';

if($post) {

$day1Temp = $_POST['temperature1'];
$day1PrecipType = $_POST['precip1'];
$day1PrecipAmountlow = $_POST['precip1a'];
$day1PrecipAmounthigh = $_POST['precip1b'];
$day1PrecipAmountSingle = $_POST['precip1c'];


$day2Temp = $_POST['temperature2'];
$day2PrecipType = $_POST['precip2'];
$day2PrecipAmountlow = $_POST['precip2a'];
$day2PrecipAmounthigh = $_POST['precip2b'];
$day2PrecipAmountSingle = $_POST['precip2c'];

$day3Temp = $_POST['temperature3'];
$day3PrecipType = $_POST['precip3'];
$day3PrecipAmountlow = $_POST['precip3a'];
$day3PrecipAmounthigh = $_POST['precip3b'];
$day3PrecipAmountSingle = $_POST['precip3c'];
  
  if($day1PrecipAmountSingle == NULL)
  {
    mysqli_query($con, "TRUNCATE TABLE userinputforecast");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, precipamount) 
      VALUES ('$forecast1', '$cloudcoverday1', '$day1Temp', '$day1PrecipType', '$day1PrecipAmountlow', '$day1PrecipAmounthigh', '$precipAmountDay1')");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
      VALUES ('$forecast2', '$cloudcoverday2', '$day2Temp', '$day2PrecipType', '$day2PrecipAmountlow', '$day2PrecipAmounthigh')");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
      VALUES ('$forecast3', '$cloudcoverday3', '$day3Temp', '$day3PrecipType', '$day3PrecipAmountlow', '$day3PrecipAmounthigh')");
  }
  else
  {
    mysqli_query($con, "TRUNCATE TABLE userinputforecast");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh, precipamount) 
      VALUES ('$forecast1', '$cloudcoverday1', '$day1Temp', '$day1PrecipType', '$day1PrecipAmountlow', '$day1PrecipAmounthigh', '$day1PrecipAmountSingle')");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
      VALUES ('$forecast2', '$cloudcoverday2', '$day2Temp', '$day2PrecipType', '$day2PrecipAmountlow', '$day2PrecipAmounthigh')");
    mysqli_query($con, "INSERT INTO userinputforecast (forecastday, cloudcover, temperature, preciptype, precipamountlow, precipamounthigh) 
      VALUES ('$forecast3', '$cloudcoverday3', '$day3Temp', '$day3PrecipType', '$day3PrecipAmountlow', '$day3PrecipAmounthigh')");
  } 
  header("Location: index.php");
}

mysqli_close($con);
?>
<? ob_flush(); ?>
</div>
</body>
</html>