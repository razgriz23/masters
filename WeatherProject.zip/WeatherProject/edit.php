<!DOCTYPE html>
<html>
<head>
<style>
body {
	font-family: Arial, Helvetica, sans-serif;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  font-family: Arial, Helvetica, sans-serif;
}

li {
  float: left;
}

a.head:link, a.head:visited {
    display: block;
    width: 200px;
    font-weight: bold;
    color: #FFFFFF;
    background-color: blue;
    text-align: center;
    padding: 3px;
    text-decoration: none;
    text-transform: uppercase;
    border-style: solid;
}

a.head:hover, a.head:active {
    background-color: red;
}

a.delete:link {
	display: block;
	font-weight: bold;
	color: red;
	text-align: center;
	width: 120px;
	padding: 4px;
}

#params {
	float: left;
}

</style>
<div id="header">
<ul>
  <li><a class="head" href="index.php">Main Page</a></li>
  <li><a class="head" href="adminpanel.php">Admin Panel</a></li>
  <li><a class="head" href="userparameterselect.php">Select Parameter</a></li>
  <li><a class="head" href="forecastuserinput.php">Enter Own Forecast</a></li>
  <li><a class="head" href="faq.html">FAQ</a></li>
</ul>
</div>

</head>
<body>

<div id="params">
<h1>Editing Application</h1>

<form action="" method="post">
<strong>Weather Condition:</strong> <input type="text" name="parameter"> </br>
<strong>Weight of parameter to be used in calculation</storng> <input type="number" step="any" name="weight">
<input type="submit" name = "submit" value="Submit">
</form>

<form action="index.php">
	<input type="submit" value="Go back to home page">
</form>
<?php
include "serverconnect.php";
$post = isset($_POST["submit"]) ? $_POST["submit"] : '';
if($post) {  //user hits submit button

	$parameter = isset($_POST["parameter"]) ? $_POST["parameter"] : '';
	$weight = isset($_POST["weight"]) ? $_POST["weight"] : '';

	$checkRow = mysqli_num_rows(mysqli_query($con, "SELECT * FROM parametertable"));
	$result = mysqli_query($con, "SELECT * FROM parametertable")
		or die(mysqli_error());
	$boolean = "false";

	if($checkRow < 1)	
	{
		mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
	}

	$result = mysqli_query($con, "SELECT parameter FROM parametertable WHERE parameter = '$parameter'")
			or die(mysqli_error());

	$row = mysqli_fetch_array($result);

	if($row[0] == NULL) //check to see if parameter is in table already
	{
		mysqli_query($con, "INSERT INTO parametertable (parameter, weight) 
			VALUES ('$parameter', '$weight')");
	}
	else //parameter is in table. Update it.
	{
		mysqli_query($con, "UPDATE parametertable SET weight = '$weight' WHERE parameter = '$parameter'");
	}

	header("Location: index.php");
}
?>  
<p><u>Current List of Parameters and Weights in Database</u></p>
<?php

	$result = mysqli_query($con, "SELECT * FROM parametertable")
		or die(mysqli_error());

	$row = mysqli_fetch_array($result);
	if($result->num_rows > 0)
	{
		echo $row["parameter"] . " " . "Weight: " . $row["weight"] . '<a class="delete" href="delete.php?id=' . $row['id'] . '"> Delete</a>' . "<br>";
		while($row = $result->fetch_assoc())
		{
			echo $row["parameter"] . " " . "Weight: " . $row["weight"] . '<a class="delete" href="delete.php?id=' . $row['id'] . '"> Delete</a>' . "<br>";
		}
	}
	mysqli_close($con);
?>
</div>

</body>
</html>