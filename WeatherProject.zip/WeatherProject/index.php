<!DOCTYPE html>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php
include 'serverconnect.php';
?>
<head>
<style type="text/css">
table{
  margin: 50px 0;
}
</style>
<style>
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	background-color: #b0c4de;
	font-family: Arial, Helvetica, sans-serif;
}

li {
	display: inline;
}
</style>
<ul>
	<li><a href="adminpanel.php">Admin Panel</a></li>
	<li><a href="edit.php">Add/Edit A Parameter</a></li>
	<li><a href="forecastuserinput.php">Enter Own Forecast</a></li>
	<li><a href="userparameterselect.php">Select Closing/Impact Parameters</a></li>
	<li><a href="#forecast">Forecast</a></li>
</ul>

<style>
#criteria {
	position: absolute;
	top: 200px;
	left: 0;
	right: 0;
	
	margin: auto;
}
#currentwx {
	position: absolute;
	left: 800px;
	top: -100px;
}
#decision {
	position: absolute;
	left: 100px;
	top: 40px;
	border: 2px solid red;
	font-family: Arial, Helvetica, sans-serif;
}
#criteriatable {
	width: 100px;
	height: 100px;

	position: absolute;
	top: 0;
	bottom: 0;
	left: 0;
	right: 0;
	
	margin: 10px;	
}

#forecast {
    margin: 10px;
}

</style>
</head>
<body>

<?php
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {
	$mainPageLook = $row['mainpagewxlook'];
}
/****************************************************************************/
echo $mainPageLook;
#if($mainPageLook == 'closing_criteria current_wx forecast')
#{
?>
<div id="decision">
Decision:
<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {

	$parameterTotal =  $row['parameterTotal'];
}

if($parameterTotal > 50 && $parameterTotal < 100)
{
	echo "It would be best to think about closing down.";
}
else if($parameterTotal > 100)
{
	echo "Highly suggest to close down.";
}
else if($parameterTotal || $parameterTotal == 0)
{
	echo "No need to close down.";
}
?>
</div>

<div id="criteria">
<?php
	 include('SevereWeatherModel.php');
?>
</div>


<div id="currentwx">
<?php
	include('currentwx.php');
?>
</div>

<div id="criteriatable">
<?php
include('criteriatable.php');
?>
</div>

<div id="forecast">
<h2 id="forecast"></h2>
<?php
include('serverconnect.php');
$result = mysqli_query($con, "SELECT * FROM userinputforecast")
	or die(mysqli_error($con));

$rowcnt = $result->num_rows;

$forecastInput = array();
while($row = mysqli_fetch_array( $result )) {

	array_push($forecastInput, $row);

}
//print_r($forecastInput);
echo '<br>';
mysqli_close($con);

#print_r($forecastInput[0]);

if($forecastInput[0][0] == 'today')
{
	$currentDay = 'Today';
}
else if($forecastInput[0][0] == 'this_afternoon')
{
	$currentDay = 'This Afternoon';
}
else if($forecastInput[0][0] == 'tonight')
{
	$currentDay = 'Tonight';
}

if($forecastInput[1][0] == 'tonight')
{
	$forecastPeriod1 = 'Tonight';
}
else if($forecastInput[1][0] == 'tomorrow')
{
	$forecastPeriod1 = 'Tomorrow';
}




if($forecastInput[0][1] == 'clear_skies')
{
	$currentDayCloud = 'Clear Skies';
}
else if($forecastInput[0][1] == 'mostly')
{
	$currentDayCloud = 'Mostly Cloudy';
}
else if($forecastInput[0][1] == 'cloudy')
{
	$currentDayCloud = 'Cloudy';
}

if($forecastInput[1][1] == 'clear_skies')
{
	$forecastPeriod1Cloud = 'Clear Skies';
}




$currentDayTemps = $forecastInput[0][2];
$forecastPeriod1Temps = $forecastInput[1][2];


#precip
if($forecastInput[0][3] == 'none')
{
	$currentDayPrecip = '';
}
if($forecastInput[1][3] == 'none')
{
	$forecastPeriod1Precip = '';
}

#clear skies
if($forecastPeriod1 == 'Tonight' || $forecastPeriod1 == 'Tomorrow Night' && $forecastPeriod1Cloud == 'Clear Skies')
{
	$forecastPeriod1Symbol = '<img src="clear-night.png" alt="ClearNight" style="width:100px; height:100px">';
}
if($forecastPeriod1 == 'Tomorrow' && $forecastPeriod1Cloud == 'Clear Skies')
{
	$forecastPeriod1Symbol = '<img src="Sunny.png" alt="Sunny" style="width:100px; height:100px">';
}
if($currentDay == 'Tonight' && $currentDayCloud == 'Clear Skies')
{ 
	$currentDaySymbol = '<img src="clear-night.png" alt="MostlyCloudy" style="width:100px; height:100px">';
}
if($currentDay == 'This Afternoon' && $currentDayCloud == 'Clear Skies')
{ 
	$currentDaySymbol = '<img src="Sunny.png" alt="Sunny" style="width:100px; height:100px">';
}

#mostly cloudy
if($currentDay == 'Today' || $currentDay == 'This Afternoon' && $currentDayCloud == 'Mostly Cloudy')
{ 
	$currentDaySymbol = '<img src="mostlycloudyday.png" alt="MostlyCloudy" style="width:100px; height:100px">';
}
else if($currentDay == 'Tonight'  && $currentDayCloud == 'Mostly Cloudy')
{ 
	$currentDaySymbol = '<img src="mostly-cloudy-night.png" alt="MostlyCloudyNight" style="width:100px; height:100px">';
}

echo "<table border='1' cellpadding='1'>";
echo "<tr> <th>Forecast</th></tr>";
echo "<tr> <th> </th> <th>Forecast Day</th> <th>Cloud Cover</th> <th>Temperatures</th> <th>Precipitation</th></tr>";
echo "<tr>";
	echo '<td>' . $currentDaySymbol . '</td>';
	echo '<td>' . $currentDay . '</td>';
	echo '<td>' . $currentDayCloud . '</td>';
	echo '<td>' . $currentDayTemps . '</td>';
	echo '<td>' . $currentDayPrecip . '</td>';
echo "</tr>"; 
echo "<tr>";
	echo '<td>' . $forecastPeriod1Symbol . '</td>';
	echo '<td>' . $forecastPeriod1 . '</td>';
	echo '<td>' . $forecastPeriod1Cloud. '</td>';
	echo '<td>' . $forecastPeriod1Temps . '</td>';
	echo '<td>' . $forecastPeriod1Precip . '</td>';
echo "</tr>";



?>



<table id="datatable">
	<thead>
		<tr>
			<th></th>
			<th>Jane</th>
			<th>John</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<th>Apples</th>
			<td contentEditable>3</td>
			<td contentEditable>4</td>
		</tr>
		<tr>
			<th>Pears</th>
			<td contentEditable>2</td>
			<td contentEditable>0</td>
		</tr>
		<tr>
			<th>Plums</th>
			<td contentEditable>5</td>
			<td contentEditable>11</td>
		</tr>
		<tr>
			<th>Bananas</th>
			<td contentEditable>1</td>
			<td contentEditable>1</td>
		</tr>
		<tr>
			<th>Oranges</th>
			<td contentEditable>2</td>
			<td contentEditable>4</td>
		</tr>
	</tbody>
</table>
<button>test</button>

<script src="http://code.highcharts.com/highcharts.js"></script>
<script src="http://code.highcharts.com/modules/data.js"></script>
<script src="http://code.highcharts.com/modules/exporting.js"></script>

<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

<script>
$(function () {
$('button').click(function(){
    $('#container').highcharts({
        data: {
            table: document.getElementById('datatable')
        },
        chart: {
            type: 'column'
        },
        title: {
            text: 'Data extracted from a HTML table in the page'
        },
        yAxis: [{
            allowDecimals: false,
            title: {
                text: 'Units'
            }
        }, {
            opposite: true,
            allowDecimals: false,
            title: {
                text: 'Another units'
            }
        }],
        tooltip: {
            formatter: function() {
                return '<b>'+ this.series.name +'</b><br/>'+
                    this.point.y +' '+ this.point.name.toLowerCase();
            }
        },
        series: [{
            yAxis: 0
        }, {
            type: 'spline',
            yAxis: 1
        }]
    });
 
});
});
</script>
</div>
<?php

/************************************************************************************/
/*else if($mainPageLook == 'closing_criteria forecast') {?>

<div id="decision">
Decision:
<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());


while($row = mysqli_fetch_array( $result )) {

	$parameterTotal =  $row['parameterTotal'];
}

mysqli_close($con);

if($parameterTotal > 50 && $parameterTotal < 100)
{
	echo "It would be best to think about closing down.";
}
else if($parameterTotal > 100)
{
	echo "Highly suggest to close down.";
}
else if($parameterTotal)
{
	echo "No need to close down.";
}
?>
</div>

<div id="criteria">
<?php
echo '<br>' . '<br>' .'<br>';
	 include('SevereWeatherModel.php');
?>
</div>

<div id="criteriatable">
<?php
include('criteriatable.php');
?>
</div>
<?php
}*/
?>

</body>
</html>
