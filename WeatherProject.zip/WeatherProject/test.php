<?php
  $q=$_GET["q"];
  $server = 'localhost';
	$user = 'root';
	$pass = 'Weather8';
	$db = 'weatherproject';

$con=mysqli_connect($server, $user, $pass, $db);

  $sql_query = "SELECT parameter FROM user userparameterselect";

  
  if (!$con){ die('Could not connect: ' . mysql_error()); }
  mysql_select_db($dbname, $con);
  $result = mysql_query($sql_query);
  echo "{ \"cols\": [ {\"id\":\"\",\"label\":\"Name-Label\",\"pattern\":\"\",\"type\":\"string\"}, {\"id\":\"\",\"label\":\"PointSum\",\"pattern\":\"\",\"type\":\"number\"} ], \"rows\": [ ";
  $total_rows = mysql_num_rows($result);
  $row_num = 0;
  while($row = mysql_fetch_array($result)){
    $row_num++;
    if ($row_num == $total_rows){
      echo $row['parameter'];
    } else {
      echo $row['parameter'];
    }
  }
  echo " ] }";
  mysql_close($con);
?>