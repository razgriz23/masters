<!DOCTYPE html>
<?php
include 'serverconnect.php';
?>
<head>
<style>
ul {
	list-style-type: none;
	margin: 0;
	padding: 0;
	background-color: #b0c4de;
}

li {
	display: inline;
}
</style>
<ul>
	<li><a href="adminpanel.php">Admin Panel</a></li>
	<li><a href="edit.php">Add A Parameter</a></li>
	<li><a href="forecastuserinput.php">Enter Own Forecast</a></li>
	<li><a href="userparameterselect.php">Select Closing/Impact Parameters</a></li>
</ul>

<style>

#currentwx {
	position: relative;
	left: 700px;
	top: -700px;
}
#decision {
	position: absolute;
	left: 100px;
	top: 60px;
	border: 2px solid red;
	font-family: Arial, Helvetica, sans-serif;
}
#criteriatable {
	position: absolute;
	top:900px;
}
</style>
</head>
<body>
<div id="decision">
Decision:
<?php
// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}


$result = mysqli_query($con, "SELECT * FROM userpreferences")
	or die(mysqli_error());
while($row = mysqli_fetch_array( $result )) {

	$parameterTotal =  $row['parameterTotal'];
}

mysqli_close($con);

if($parameterTotal > 50 && $parameterTotal < 100)
{
	echo "It would be best to think about closing down.";
}
else if($parameterTotal > 100)
{
	echo "Highly suggest to close down.";
}
else
{
	echo "No need to close down.";
}
?>
</div>

<div id="criteria">
<?php
echo '<br>' . '<br>' .'<br>';
	 include('SevereWeatherModel.php');
?>
</div>


<div id="currentwx">
<?php
	include('currentwx.php');
?>
</div>

<div id="criteriatable">
<?php
include('criteriatable.php');
?>
</div>

</body>
</html>
